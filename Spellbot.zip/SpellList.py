bard_cantrips = [
    "Blade Ward", "Dancing Lights", "Friends", "Light", "Mage Hand",
    "Mending", "Message", "Minor Illusion", "Prestidigitation",
    "Thunderclap", "True Strike", "Vicious Mockery"]

bard_first_level_spells = [
    "Animal Friendship", "Bane", "Charm Person", "Color Spray", "Command",
    "Comprehend Languages", "Cure Wounds", "Detect Magic", "Disguise Self",
    "Dissonant Whispers", "Distort Value", "Earth Tremor", "Faerie Fire",
    "Feather Fall", "Healing Word", "Heroism", "Identify", "Illusory Script",
    "Longstrider", "Silent Image", "Silvery Barbs", "Sleep",
    "Speak with Animals", "Tasha's Hideous Laughter", "Thunderwave",
    "Unseen Servant"]

bard_second_level_spells = [
    "Aid", "Animal Messenger", "Blindness/Deafness", "Borrow Knowledge",
    "Calm Emotions", "Cloud of Daggers", "Crown of Madness", "Detect Thoughts",
    "Enhance Ability", "Enlarge/Reduce", "Enthrall", "Gift of Gab",
    "Heat Metal", "Hold Person", "Invisibility", "Kinetic Jaunt", "Knock",
    "Lesser Restoration", "Locate Animals or Plants", "Locate Object",
    "Magic Mouth", "Mirror Image", "Nathair's Mischief", "Phantasmal Force",
    "Pyrotechnics", "See Invisibility", "Shatter", "Silence", "Skywrite",
    "Spray Of Cards", "Suggestion", "Warding Wind", "Zone Of Truth"]

bard_third_level_spells = [
    "Antagonize", "Bestow Curse", "Catnap", "Clairvoyance", "Dispel Magic",
    "Enemies Abound", "Fast Friends", "Fear", "Feign Death",
    "Glyph of Warding", "Hypnotic Pattern", "Leomund's Tiny Hut",
    "Major Image", "Mass Healing Word", "Motivational Speech", "Nondetection",
    "Plant Growth", "Sending", "Speak with Dead", "Stinking Cloud", "Tongues"]

cleric_cantrips = [
    "Decompose", "Guidance", "Hand Of Radiance", "Light", "Mending",
    "Resistance", "Sacred Flame", "Spare The Dying", "Thaumaturgy",
    "Toll The Dead", "Word Of Radiance"]

cleric_first_level_spells = [
    "Bane", "Bless", "Ceremony", "Command", "Create And Destroy Water",
    "Cure Wounds", "Detect Evil And Good", "Detect magic",
    "Detect Poison And Disease", "Guideing Bolt", "Guiding Hand",
    "Healing Word", "inflict Wounds", "Protection From Evil And Good",
    "Purify Food And Drink", "Sanctuary", "Shield Of Faith"]

cleric_second_level_spells = [
    "Aid", "Augury", "Blindness/Deafness", "Calm Emotions",
    "Continual Flame", "Enhance Ability", "Find Traps", "Gentle Repose",
    "Hold Person", "Lesser Restoration", "Locate Object",
    "Prayer Of Healing", "Protection from poison", "Silence",
    "Spiritual Weapon", "Warding Bond", "Zone Of Truth"]

cleric_third_level_spells = [
    "Animate Dead", "Aura Of Vitality", "Beacon Of Hope",
    "Bestow Curse", "Clairvoyance", "Create Food And Water",
    "Daylight", "Dispel Magic", "Fast Friends", "Feign Death",
    "Glyph Of Warding", "Incite Greed", "Life Transference",
    "Magic Circle", "Mass healing Word", "Protection From Energy",
    "Remove Curse", "Revivify", "Sending", "Speak With Dead",
    "Spirit Guardians", "Spirit Shroud", "tongues", "Water Walk"]

druid_cantrips = [
    "Control Flames", "Create Bonfire", "Druidcraft", "Frostbite",
    "Guidance", "Gust", "Infestation", "Magic Stone", "Mending",
    "Mold Earth", "Poison Spray", "Primal Savagery", "Produce Flame",
    "Resistance", "Shape Water", "Shillelagh", "Thorn Whip", "Thunderclap"]

druid_first_level_spells = [
    "Absorb Elements", "Animal Friendship", "Beast Bond", "Charm Person",
    "Create Or Destroy Water", "Cure Wounds", "Detect magic",
    "Detect Poison And Disease", "Earth Tremor", "Entangle", "Faerie Fire",
    "Fog Cloud", "Goodberry", "Guiding hand", "Healing Word", "Ice Knife",
    "Jump", "Longstrider", "Protection From Evil And Good", "Purify Food And Drink",
    "Thunderwave", "Wild Cunning"]

druid_second_level_spells = [
    "Air Bubble", "Animal Messenger", "Augury", "Barkskin",
    "Beast Sense", "Continual Flame", "Darkvision", "Dust Devil",
    "Earthbind", "Enhance Ability", "Enlarge/Reduce", "Find Traps",
    "Flame Blade", "Flaming Sphere", "Gust Of Wind", "Healing Spirit",
    "Heat Metal", "Hold Person", "Lesser Restoration",
    "Locate Animals Or Plants", "Locate Objects", "Moonbeam",
    "Pass Without Trace", "Protection From Poison", "Skywrite",
    "Spike Growth", "Summon Beast", "Warding Wind", "Wither And Bloom"]

druid_third_level_spells = [
    "Aura of Vitality", "Call lightning", "Conjure Animals", "Daylight",
    "Dispel Magic", "Elemental Weapon", "Erupting Earth", "Feign Death",
    "Flame Arrows", "Freedom Of The Waves", "Meld Into Stone",
    "Plant Growth", "Protections From Energy", "Revivify",
    "Sleet Storm", "Speak With Plants", "Summon Fey", "Tidal Wave",
    "Wall Of Water", "Water Breathing", "Water Walk", "Wind Wall"]

sorcerer_cantrips = [
    "Acid Splash", "Blade Ward", "Booming Blade", "Chill Touch",
    "Control Flames", "Create Bonfire", "Dancing Lights", "Fire Bolt",
    "Friends", "Frostbite", "Green-Flame Blade", "Gust", "Infestation",
    "Light", "Lightning Lure", "Mage hand", "Mending", "Message",
    "Mind Silver", "Minor Illusion", "Mold Earth", "On/Off",
    "Poison Spray", "Prestidigitation", "Ray Of Frost", "Shape Water",
    "Schoking Grasp", "Sword Burst", "Thunderclap", "True Strike"]

sorcerer_first_level_spells = [
    "Burning Hands", "Charm Person", "Chromatic Orb", "Color Spray",
    "Comprehend Languages", "Detect Magic", "Disguise Self",
    "Expeditious Retreat", "False Life", "Feather Fall", "Fog Cloud",
    "Jump", "Mage Armor", "Magic Missile", "Ray of Sickness", "Shield",
    "Silent Image", "Sleep", "Thunderwave", "Witch Bolt"]

sorcerer_second_level_spells = [
    "Alter Self", "Blindness/Deafness", "Blur", "Cloud of Daggers",
    "Crown of Madness", "Darkness", "Darkvision", "Detect Thoughts",
    "Enhance Ability", "Enlarge/Reduce", "Gust of Wind", "Hold Person",
    "Invisibility", "Knock", "Levitate", "Mirror Image", "Misty Step",
    "Phantasmal Force", "Scorching Ray", "See Invisibility", "Shatter",
    "Spider Climb", "Suggestion", "Web"]

sorcerer_third_level_spells = [
    "Blink", "Clairvoyance", "Counterspell", "Daylight",
    "Dispel Magic", "Fear", "Fireball", "Fly", "Gaseous Form",
    "Haste", "Hypnotic Pattern", "Lightning Bolt", "Major Image",
    "Protection from Energy", "Sleet Storm", "Slow", "Stinking Cloud",
    "Tongues", "Water Breathing", "Water Walk"]

wizard_cantrips = [
    "Acid Splash", "Blade Ward", "Booming Blade", "Chill Touch",
    "Control Flames", "Create Bonfire", "Dancing Lights", "Encode Thoughts",
    "Fire Bolt", "Friends", "Frostbite", "Green-Flame Blade", "Gust",
    "Infestation", "Light", "Lightning Lure", "Mage Hand", "Mending",
    "Message", "Mind Sliver", "Minor Illusion", "Mold Earth", "On/Off (UA)",
    "Poison Spray", "Prestidigitation", "Ray of Frost", "Sapping Sting",
    "Shape Water", "Shocking Grasp", "Sword Burst", "Thunderclap",
    "Toll the Dead", "True Strike"]

wizard_first_level_spells = [
    "Absorb Elements", "Acid Stream", "Alarm", "Burning Hands", "Catapult",
    "Cause Fear", "Charm Person", "Chromatic Orb", "Color Spray",
    "Comprehend Languages", "Detect Magic", "Disguise Self", "Distort Value",
    "Earth Tremor", "Expeditious Retreat", "False Life", "Feather Fall",
    "Find Familiar", "Fog Cloud", "Frost Fingers", "Gift of Alacrity",
    "Grease", "Guiding Hand", "Healing Elixir", "Ice Knife", "Id Insinuation",
    "Identify", "Illusory Script", "Infallible Relay", "Jim's Magic Missile",
    "Jump", "Longstrider", "Mage Armor", "Magic Missile", "Magnify Gravity",
    "Protection from Evil and Good", "Puppet", "Ray of Sickness",
    "Remote Access", "Sense Emotion", "Shield", "Silent Image",
    "Silvery Barbs", "Sleep", "Snare", "Sudden Awakening",
    "Tasha's Caustic Brew", "Tasha's Hideous Laughter",
    "Tenser's Floating Disk", "Thunderwave", "Unseen Servant",
    "Witch Bolt"]

wizard_second_level_spells = [
    "Aganazzar's Scorcher", "Air Bubble", "Alter Self", "Arcane Hacking",
    "Arcane Lock", "Augury", "Blindness/Deafness", "Blur",
    "Borrowed Knowledge", "Cloud of Daggers", "Continual Flame",
    "Crown of Madness", "Darkness", "Darkvision", "Detect Thoughts",
    "Digital Phantom", "Dragon's Breath", "Dust Devil", "Earthbind",
    "Enhance Ability", "Enlarge/Reduce", "Find Vehicle", "Flaming Sphere",
    "Flock of Familiars", "Fortune's Favor", "Gentle Repose",
    "Gift of Gab", "Gust of Wind", "Hold Person", "Icingdeath's Frost",
    "Immovable Object", "Invisibility", "Jim's Glowing Coin",
    "Kinetic Jaunt", "Knock", "Levitate", "Locate Object", "Magic Mouth",
    "Magic Weapon", "Maximillian's Earthen Grasp", "Melf's Acid Arrow",
    "Mental Barrier", "Mind Spike", "Mind Thrust", "Mirror Image",
    "Misty Step", "Nathair's Mischief", "Nystul's Magic Aura",
    "Phantasmal Force", "Pyrotechnics", "Ray of Enfeeblement",
    "Rime's Binding Ice", "Rope Trick", "Scorching Ray",
    "See Invisibility", "Shadow Blade", "Shatter", "Skywrite",
    "Snilloc's Snowball Storm", "Spider Climb", "Spray Of Cards",
    "Suggestion", "Tasha's Mind Whip", "Thought Shield", "Vortex Warp",
    "Warding Wind", "Warp Sense", "Web", "Wither and Bloom", "Wristpocket"]

wizard_third_level_spells = [
    "Animate Dead", "Antagonize", "Antagonize", "A shardalon's Stride",
    "Bestow Curse", "Blink", "Catnap", "Clairvoyance", "Conjure Lesser Demon",
    "Counterspell", "Dispel Magic", "Enemies Abound", "Erupting Earth",
    "Fast Friends", "Fear", "Feign Death", "Fireball", "Flame Arrows",
    "Flame Stride", "Fly", "Galder's Tower", "Gaseous Form", "Glyph of Warding",
    "Haste", "Haywire", "House of Cards", "Hypnotic Pattern", "Incite Greed",
    "Intellect Fortress", "Invisibility To Cameras", "Leomund's Tiny Hut",
    "Life Transference", "Lightning Bolt", "Magic Circle", "Major Image",
    "Melf's Minute Meteors", "Nondetection", "Phantom Steed",
    "Protection from Ballistics", "Protection from Energy", "Psionic Blast",
    "Pulse Wave", "Remove Curse", "Sending", "Sleet Storm", "Slow",
    "Speak with Dead", "Spirit Shroud", "Stinking Cloud", "Summon Fey",
    "Summon Lesser Demons", "Summon Shadowspawn", "Summon Undead",
    "Summon Warrior Spirit", "Thunder Step", "Tidal Wave", "Tiny Servant",
    "Tongues", "Vampiric Touch", "Wall of Sand", "Wall of Water",
    "Water Breathing"]




spell_details = { 
                                    #cantrips
                                    "acid splash": {
                                                    "name": "Acid Splash",
                                                    "school": "Conjuration",
                                                    "casting time": "1 Action",
                                                    "range": "60 feet",
                                                    "duration": "Instantaneous",
                                                    "components": "Verbal, Somatic",
                                                    "description": "You hurl a bubble of acid. Choose one creature you can see within range, or choose two creatures you can see within range that are within 5 feet of each other. A target must succeed on a Dexterity saving throw or take 1d6 acid damage. \n \nAt Higher Levels: This spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6)." 
                                    },
                                     "blade ward": {
                                                     "name": "Blade Ward",
                                                     "school": "Abjuration",
                                                     "casting time": "1 Action",
                                                     "range": "Self",
                                                     "duration": "1 round",
                                                     "components": "Verbal, Somatic",
                                                     "description": "You extend your hand and trace a sigil of warding in the air. Until the end of your next turn, you have resistance against bludgeoning, piercing, and slashing damage dealt by weapon attacks."
                                    },
                                    "booming blade": {
                                                    "name": "Booming Blade",
                                                    "school": "Evocation",
                                                    "casting time": "1 Action",
                                                    "range": "Self (5-foot radius)",
                                                    "duration": "1 round",
                                                    "components": "Somatic, Material",
                                                    "description": "You brandish the weapon used in the spell’s casting and make a melee attack with it against one creature within 5 feet of you. On a hit, the target suffers the weapon attack’s normal effects and then becomes sheathed in booming energy until the start of your next turn. If the target willingly moves 5 feet or more before then, the target takes 1d8 thunder damage, and the spell ends.\n\n**At Higher Levels.** At 5th level, the melee attack deals an extra 1d8 thunder damage to the target on a hit, and the damage the target takes for moving increases to 2d8. Both damage rolls increase by 1d8 at 11th level (2d8 and 3d8) and again at 17th level (3d8 and 4d8)."
                                    },
                                    "chill touch": {
                                                    "name": "Chill Touch",
                                                    "school": "Necromancy",
                                                    "casting time": "1 Action",
                                                    "range": "120 feet",
                                                    "duration": "1 round",
                                                    "components": "Verbal, Somatic",
                                                    "description": "You create a ghostly, skeletal hand in the space of a creature within range. Make a ranged spell attack against the creature to assail it with the chill of the grave. On a hit, the target takes 1d8 necrotic damage, and it can’t regain hit points until the start of your next turn. Until then, the hand clings to the target. If you hit an undead target, it also has disadvantage on attack rolls against you until the end of your next turn."
                                    },
                                    "control flames": {
                                                    "name": "Control Flames",
                                                    "school": "Transmutation",
                                                    "casting time": "1 Action",
                                                    "range": "60 Feet",
                                                    "duration": "Instantaneous or 1 hour",
                                                    "components": "Somatic",
                                                    "description": "You choose nonmagical flame that you can see within range and that fits within a 5-foot cube. You affect it in one of the following ways: \n- You instantaneously expand the flame 5 feet in one direction, provided that wood or other fuel is present in the new location. \n- You instantaneously extinguish the flames within the cube. \n- You double or halve the area of bright light and dim light cast by the flame, change its color, or both. The change lasts for 1 hour. \n- You cause simple shapes—such as the vague form of a creature, an inanimate object, or a location—to appear within the flames and animate as you like. The shapes last for 1 hour. \nIf you cast this spell multiple times, you can have up to three of its non-instantaneous effects active at a time, and you can dismiss such an effect as an action."
                                    },
                                    "create bonfire": {
                                                        "name": "Create Bonfire",
                                                        "school": "Conjuration",
                                                        "casting time": "1 Action",
                                                        "range": "60 Feet",
                                                        "duration": "Concentration, up to 1 minute",
                                                        "components": "Verbal, Somatic",
                                                        "description": "You create a bonfire on ground that you can see within range. Until the spell ends, the bonfire fills a 5-foot cube. Any creature in the bonfire’s space when you cast the spell must succeed on a Dexterity saving throw or take 1d8 fire damage. A creature must also make the saving throw when it enters the bonfire’s space for the first time on a turn or ends its turn there.\n \n **At Higher Levels.** The spell’s damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8)."
                                                    },
                                    "dancing lights": {
                                                        "name": "Dancing Lights",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "120 feet",
                                                        "duration": "Concentration, up to 1 minute",
                                                        "components": "Verbal, Somatic, Material",
                                                        "description": "You create up to four torch-sized lights within range, making them appear as torches, lanterns, or glowing orbs that hover in the air for the duration. You can also combine the four lights into one glowing vaguely humanoid form of Medium size. Whichever form you choose, each light sheds dim light in a 10-foot radius.\n \n As a bonus action on your turn, you can move the lights up to 60 feet to a new spot within range. A light must be within 20 feet of another light created by this spell, and a light winks out if it exceeds the spell’s range."
                                                    },
                                    "decompose": {
                                                        "name": "Decompose (HB)",
                                                        "school": "Necromancy",
                                                        "casting time": "1 Action",
                                                        "range": "Touch",
                                                        "duration": "1 minute",
                                                        "components": "Verbal, Somatic",
                                                        "description": "You reach out and touch the corpse of a creature. Over the next minute, the corpse begins to rapidly decompose, sprouting fungus and moss as it begins to degrade into compost and mulch. An odd-colored flower or two may also spring from the corpse in this time. Applicable requirements for resurrection are unaffected by this decomposition."
                                                    },
                                    "druidcraft": {
                                                        "name": "Druidcraft",
                                                        "school": "Transmutation",
                                                        "casting time": "1 Action",
                                                        "range": "30 Feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "Whispering to the spirits of nature, you create one of the following effects within range: \n \n You create a tiny, harmless sensory effect that predicts what the weather will be at your location for the next 24 hours. The effect might manifest as a golden orb for clear skies, a cloud for rain, falling snowflakes for snow, and so on. This effect persists for 1 round.\n You instantly make a flower blossom, a seed pod open, or a leaf bud bloom. \n You create an instantaneous, harmless sensory effect, such as falling leaves, a puff of wind, the sound of a small animal, or the faint odor of skunk. The effect must fit in a 5-foot cube. \n You instantly light or snuff out a candle, a torch, or a small campfire."
                                                    },
                                    "eldritch blast": {
                                                        "name": "Eldritch Blast",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "120 Feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "A beam of crackling energy streaks toward a creature within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 force damage. \n \n **At Higher Levels.** The spell creates more than one beam when you reach higher levels: two beams at 5th level, three beams at 11th level, and four beams at 17th level. You can direct the beams at the same target or at different ones. Make a separate attack roll for each beam."
                                                    },
                                    "encode thoughts": {
                                                        "name": "Encode Thoughts",
                                                        "school": "Enchantment",
                                                        "casting time": "1 Action",
                                                        "range": "Self",
                                                        "duration": "8 hours",
                                                        "components": "Somatic",
                                                        "description": "You pull a memory, an idea, or a message from your mind and transform it into a tangible string of glowing energy called a thought strand, which persists for the duration or until you cast this spell again. The thought strand appears in an unoccupied space within 5 feet of you as a Tiny, weightless, semisolid object that can be held and carried like a ribbon. It is otherwise stationary. \n \n If you cast this spell while concentrating on a spell or an ability that allows you to read or manipulate the thoughts of others (such as detect thoughts or modify memory), you can transform the thoughts or memories you read, rather than your own, into a thought strand. \n \n Casting this spell while holding a thought strand allows you to instantly receive whatever memory, idea, or message the thought strand contains. (Casting detect thoughts on the strand has the same effect.)"
                                                    },
                                    "fire bolt": {
                                                        "name": "Fire Bolt",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "120 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "You hurl a mote of fire at a creature or object within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 fire damage. A flammable object hit by this spell ignites if it isn’t being worn or carried. \n \n **At Higher Levels.** This spell’s damage increases by 1d10 when you reach 5th level (2d10), 11th level (3d10), and 17th level (4d10)."
                                                    },
                                     "friends": {
                                                         "name": "Friends",
                                                         "school": "Enchantment",
                                                         "casting time": "1 Action",
                                                         "range": "Self",
                                                         "duration": "Concentration, up to 1 minute",
                                                         "components": "Somatic, Material",
                                                         "description": "For the duration, you have advantage on all Charisma checks directed at one creature of your choice that isn't hostile toward you. When the spell ends, the creature realizes that you used magic to influence its mood and becomes hostile toward you. A creature prone to violence might attack you. Another creature might seek retribution in other ways (at the DM's discretion), depending on the nature of your interaction with it."
                                                     },
                                    "frostbite":{
                                                    "name": "Frostbite",
                                                    "school": "Evocation",
                                                    "casting time": "1 Action",
                                                    "range": "60 feet",
                                                    "duration": "Instantaneous",
                                                    "components": "Verbal, Somatic",
                                                    "description": "You cause numbing frost to form on one creature that you can see within range. The target must make a Constitution saving throw. On a failed save, the target takes 1d6 cold damage, and it has disadvantage on the next weapon attack roll it makes before the end of its next turn. \n \n **At Higher Levels.** The spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6)."
                                                    },
                                    "green flame blade": {
                                                        "name": "Green-Flame Blade",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "Self (5-foot radius)",
                                                        "duration": "Instantaneous",
                                                        "components": "Somatic, Material",
                                                        "description": "You brandish the weapon used in the spell’s casting and make a melee attack with it against one creature within 5 feet of you. On a hit, the target suffers the weapon attack’s normal effects, and you can cause green fire to leap from the target to a different creature of your choice that you can see within 5 feet of it. The second creature takes fire damage equal to your spellcasting ability modifier. \n \n **At Higher Levels.** At 5th level, the melee attack deals an extra 1d8 fire damage to the target on a hit, and the fire damage to the second creature increases to 1d8 + your spellcasting ability modifier. Both damage rolls increase by 1d8 at 11th level (2d8 and 2d8) and 17th level (3d8 and 3d8)."
                                                    },
                                    "guidance": {
                                                        "name": "Guidance",
                                                        "school": "Divination",
                                                        "casting time": "1 Action",
                                                        "range": "Touch",
                                                        "duration": "Concentration, up to 1 minute",
                                                        "components": "Verbal, Somatic",
                                                        "description": "You touch one willing creature. Once before the spell ends, the target can roll a d4 and add the number rolled to one ability check of its choice. It can roll the die before or after making the ability check. The spell then ends."
                                                    },
                                    "gust": {
                                                        "name": "Gust",
                                                        "school": "Transmutation",
                                                        "casting time": "1 Action",
                                                        "range": "30 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "You seize the air and compel it to create one of the following effects at a point you can see within range: \n \n One Medium or smaller creature that you choose must succeed on a Strength saving throw or be pushed up to 5 feet away from you. \n You create a small blast of air capable of moving one object that is neither held nor carried and that weighs no more than 5 pounds. The object is pushed up to 10 feet away from you. It isn’t pushed with enough force to cause damage. \n You create a harmless sensory affect using air, such as causing leaves to rustle, wind to slam shutters shut, or your clothing to ripple in a breeze."
                                                    },
                                    "hand of radiance": {
                                                        "name": "Hand of Radiance (UA)",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "5 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "You raise your hand, and burning radiance erupts from it. Each creature of your choice that you can see within 5 feet of you must succeed on a Constitution saving throw or take 1d6 radiant damage. \n \n **At Higher Levels:** The spell's damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6)."
                                                    },
                                    "infestation": {
                                                        "name": "Infestation",
                                                        "school": "Conjuration",
                                                        "casting time": "1 Action",
                                                        "range": "30 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic, Material",
                                                        "description": "You cause a cloud of mites, fleas, and other parasites to appear momentarily on one creature you can see within range. The target must succeed on a Constitution saving throw, or it takes 1d6 poison damage and moves 5 feet in a random direction if it can move and its speed is at least 5 feet. Roll a d4 for the direction: 1, north; 2, south; 3, east; or 4, west. This movement doesn’t provoke opportunity attacks, and if the direction rolled is blocked, the target doesn't move. \n \n **At Higher Levels.** The spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6)."
                                                    },
                                    "light": {
                                                        "name": "Light",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "Touch",
                                                        "duration": "1 hour",
                                                        "components": "Verbal, Material",
                                                        "description": "You touch one object that is no larger than 10 feet in any dimension. Until the spell ends, the object sheds bright light in a 20-foot radius and dim light for an additional 20 feet. The light can be colored as you like. Completely covering the object with something opaque blocks the light. The spell ends if you cast it again or dismiss it as an action. \n \n If you target an object held or worn by a hostile creature, that creature must succeed on a Dexterity saving throw to avoid the spell."
                                                    },
                                    "lightning lure": {
                                                        "name": "Lightning Lure",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "Self (15-foot radius)",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal",
                                                        "description": "You create a lash of lightning energy that strikes at one creature of your choice that you can see within 15 feet of you. The target must succeed on a Strength saving throw or be pulled up to 10 feet in a straight line toward you and then take 1d8 lightning damage if it is within 5 feet of you. \n \n **At Higher Levels.** This spell's damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8)."
                                                    },
                                    "mage hand": {
                                                        "name": "Mage Hand",
                                                        "school": "Conjuration",
                                                        "casting time": "1 Action",
                                                        "range": "30 feet",
                                                        "duration": "1 minute",
                                                        "components": "Verbal, Somatic",
                                                        "description": "A spectral, floating hand appears at a point you choose within range. The hand lasts for the duration or until you dismiss it as an action. The hand vanishes if it is ever more than 30 feet away from you or if you cast this spell again. \n \n You can use your action to control the hand. You can use the hand to manipulate an object, open an unlocked door or container, stow or retrieve an item from an open container, or pour the contents out of a vial. You can move the hand up to 30 feet each time you use it. \n \n The hand can’t attack, activate magical items, or carry more than 10 pounds."
                                                    },
                                    "magic stone": {
                                                        "name": "Magic Stone",
                                                        "school": "Transmutation",
                                                        "casting time": "1 Bonus Action",
                                                        "range": "Touch",
                                                        "duration": "1 minute",
                                                        "components": "Verbal, Somatic",
                                                        "description": "You touch one to three pebbles and imbue them with magic. You or someone else can make a ranged spell attack with one of the pebbles by throwing it or hurling it with a sling. If thrown, it has a range of 60 feet. If someone else attacks with the pebble, that attacker adds your spellcasting ability modifier, not the attacker’s, to the attack roll. On a hit, the target takes bludgeoning damage equal to 1d6 + your spellcasting ability modifier. Hit or miss, the spell then ends on the stone. \n \n If you cast this spell again, the spell ends early on any pebbles still affected by it."
                                                    },
                                    "mending": {
                                                    "name": "Mending",
                                                    "school": "Transmutation",
                                                    "casting time": "1 Minute",
                                                    "range": "Touch",
                                                    "duration": "Instantaneous",
                                                    "components": "Verbal, Somatic, Material",
                                                    "description": "This spell repairs a single break or tear in an object you touch, such as a broken chain link, two halves of a broken key, a torn cloak, or a leaking wineskin. As long as the break or tear is no larger than 1 foot in any dimension, you mend it, leaving no trace of the former damage.\n \n This spell can physically repair a magic item or construct, but the spell can’t restore magic to such an object."
                                               },
                                    "message": {
                                                    "name": "Message",
                                                    "school": "Transmutation",
                                                    "casting time": "1 Action",
                                                    "range": "120 feet",
                                                    "duration": "1 round",
                                                    "components": "Verbal, Somatic, Material",
                                                    "description": "You point your finger toward a creature within range and whisper a message. The target (and only the target) hears the message and can reply in a whisper that only you can hear. \n \n You can cast this spell through solid objects if you are familiar with the target and know it is beyond the barrier. Magical silence, 1 foot of stone, 1 inch of common metal, a thin sheet of lead, or 3 feet of wood blocks the spell. The spell doesn’t have to follow a straight line and can travel freely around corners or through openings."
                                                    },
                                    "mind sliver": {
                                                        "name": "Mind Sliver",
                                                        "school": "Enchantment",
                                                        "casting time": "1 Action",
                                                        "range": "60 feet",
                                                        "duration": "1 round",
                                                        "components": "Verbal",
                                                        "description": "You drive a disorienting spike of psychic energy into the mind of one creature you can see within range. The target must succeed on an Intelligence saving throw or take 1d6 psychic damage and subtract 1d4 from the next saving throw it makes before the end of your next turn. \n \n **At Higher Levels.** This spell’s damage increases by 1d6 when you reach certain levels: 5th level (2d6), 11th level (3d6), and 17th level (4d6)."
                                                    },
                                    "minor illusion": {
                                                        "name": "Minor Illusion",
                                                        "school": "Illusion",
                                                        "casting time": "1 Action",
                                                        "range": "30 feet",
                                                        "duration": "1 minute",
                                                        "components": "Somatic, Material",
                                                        "description": "You create a sound or an image of an object within range that lasts for the duration. The illusion also ends if you dismiss it as an action or cast this spell again. \n \n If you create a sound, its volume can range from a whisper to a scream. It can be your voice, someone else’s voice, a lion’s roar, a beating of drums, or any other sound you choose. The sound continues unabated throughout the duration, or you can make discrete sounds at different times before the spell ends.\n \n If you create an image of an object—such as a chair, muddy footprints, or a small chest—it must be no larger than a 5-foot cube. The image can’t create sound, light, smell, or any other sensory effect. Physical interaction with the image reveals it to be an illusion, because things can pass through it.\n \n If a creature uses its action to examine the sound or image, the creature can determine that it is an illusion with a successful Intelligence (Investigation) check against your spell save DC. If a creature discerns the illusion for what it is, the illusion becomes faint to the creature."
                                                    },
                                    "mold earth": {
                                                      "name": "Mold Earth",
                                                      "school": "Transmutation",
                                                      "casting time": "1 Action",
                                                      "range": "30 feet",
                                                      "duration": "Instantaneous or 1 hour",
                                                      "components": "Somatic",
                                                      "description": "You choose a portion of dirt or stone that you can see within range and that fits within a 5-foot cube. You manipulate it in one of the following ways:\n \n If you target an area of loose earth, you can instantaneously excavate it, move it along the ground, and deposit it up to 5 feet away. This movement doesn’t have enough force to cause damage.\n You cause shapes, colors, or both to appear on the dirt or stone, spelling out words, creating images, or shaping patterns. The changes last for 1 hour. \n If the dirt or stone you target is on the ground, you cause it to become difficult terrain. Alternatively, you can cause the ground to become normal terrain if it is already difficult terrain. This change lasts for 1 hour. \n If you cast this spell multiple times, you can have no more than two of its non-instantaneous effects active at a time, and you can dismiss such an effect as an action."
                                                  },
                                    "on/off": {
                                                        "name": "On/Off (UA)",
                                                        "school": "Transmutation",
                                                        "casting time": "1 Action",
                                                        "range": "60 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "This cantrip allows you to activate or deactivate any electronic device within range, as long as the device has a clearly defined on or off function that can be easily accessed from the outside of the device. Any device that requires a software-based shutdown sequence to activate or deactivate cannot be affected by On/Off."
                                                    },
                                    "poison spray": {
                                                        "name": "Poison Spray",
                                                        "school": "Conjuration",
                                                        "casting time": "1 Action",
                                                        "range": "10 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "You extend your hand toward a creature you can see within range and project a puff of noxious gas from your palm. The creature must succeed on a Constitution saving throw or take 1d12 poison damage. \n \n **At Higher Levels.** This spell’s damage increases by 1d12 when you reach 5th level (2d12), 11th level (3d12), and 17th level (4d12)."
                                                    },
                                    "prestidigitation": {
                                                        "name": "Prestidigitation",
                                                        "school": "Transmutation",
                                                        "casting time": "1 Action",
                                                        "range": "10 feet",
                                                        "duration": "Up to 1 hour",
                                                        "components": "Verbal, Somatic",
                                                        "description": "This spell is a minor magical trick that novice spellcasters use for practice. You create one of the following magical effects within range:\n \n You create an instantaneous, harmless sensory effect, such as a shower of sparks, a puff of wind, faint musical notes, or an odd odor.\n You instantaneously light or snuff out a candle, a torch, or a small campfire. \n You instantaneously clean or soil an object no larger than 1 cubic foot. \n You chill, warm, or flavor up to 1 cubic foot of nonliving material for 1 hour.\n You make a color, a small mark, or a symbol appear on an object or a surface for 1 hour. \n You create a nonmagical trinket or an illusory image that can fit in your hand and that lasts until the end of your next turn. \n If you cast this spell multiple times, you can have up to three of its non-instantaneous effects active at a time, and you can dismiss such an effect as an action."
                                                    },
                                    "primal savagery": {
                                                           "name": "Primal Savagery",
                                                           "school": "Transmutation",
                                                           "casting time": "1 Action",
                                                           "range": "Self",
                                                           "duration": "Self",
                                                           "components": "Verbal, Somatic",
                                                           "description": "You channel primal magic to cause your teeth or fingernails to sharpen, ready to deliver a corrosive attack. Make a melee spell attack against one creature within 5 feet of you. On a hit, the target takes 1d10 acid damage. After you make the attack, your teeth or fingernails return to normal.\n \n **At Higher Levels.** The spell’s damage increases by 1d10 when you reach 5th level (2d10), 11th level (3d10), and 17th level (4d10)."
                                                       },
                                    "produce flame": {
                                                        "name": "Produce Flame",
                                                        "school": "Conjuration",
                                                        "casting time": "1 Action",
                                                        "range": "Self",
                                                        "duration": "10 minutes",
                                                        "components": "Verbal, Somatic",
                                                        "description": "A flickering flame appears in your hand. The flame remains there for the duration and harms neither you nor your equipment. The flame sheds bright light in a 10-foot radius and dim light for an additional 10 feet. The spell ends if you dismiss it as an action or if you cast it again. \n \n You can also attack with the flame, although doing so ends the spell. When you cast this spell, or as an action on a later turn, you can hurl the flame at a creature within 30 feet of you. Make a ranged spell attack. On a hit, the target takes 1d8 fire damage.\n \n **At Higher Levels.** This spell’s damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8)."
                                                    },
                                    "ray of frost": {
                                                        "name": "Ray of Frost",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "60 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "A frigid beam of blue-white light streaks toward a creature within range. Make a ranged spell attack against the target. On a hit, it takes 1d8 cold damage, and its speed is reduced by 10 feet until the start of your next turn.\n \n **At Higher Levels.** The spell’s damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8)."
                                                    },
                                    "resistance": {
                                                        "name": "Resistance",
                                                        "school": "Abjuration",
                                                        "casting time": "1 Action",
                                                        "range": "Touch",
                                                        "duration": "Concentration up to 1 minute",
                                                        "components": "Verbal, Somatic, Material",
                                                        "description": "You touch one willing creature. Once before the spell ends, the target can roll a d4 and add the number rolled to one saving throw of its choice. It can roll the die before or after the saving throw. The spell then ends."
                                                    },
                                    "sacred flame": {
                                                        "name": "Sacred Flame",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "60 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "Flame-like radiance descends on a creature that you can see within range. The target must succeed on a Dexterity saving throw or take 1d8 radiant damage. The target gains no benefit from cover for this saving throw.\n \n **At Higher Levels.** The spell’s damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8)."
                                                    },
                                    "sapping sting": {
                                                         "name": "Sapping Sting",
                                                         "school": "Necromancy",
                                                         "casting time": "1 Action",
                                                         "range": "30 feet",
                                                         "duration": "Instantaneous",
                                                         "components": "Verbal, Somatic",
                                                         "description": "You sap the vitality of one creature you can see in range. The target must succeed on a Constitution saving throw or take 1d4 necrotic damage and fall prone.\n \n **At Higher Levels.** This spell's damage increases by 1d4 when you reach 5th level (2d4), 11th level (3d4), and 17th level (4d4)."
                                                     },
                                    "shape water": {
                                                        "name": "Shape Water",
                                                        "school": "Transmutation",
                                                        "casting time": "1 Action",
                                                        "range": "30 feet",
                                                        "duration": "Instantaneous or 1 hour",
                                                        "components": "Somatic",
                                                        "description": "You choose an area of water that you can see within range and that fits within a 5-foot cube. You manipulate it in one of the following ways:\n \nYou instantaneously move or otherwise change the flow of the water as you direct, up to 5 feet in any direction. This movement doesn’t have enough force to cause damage.\n You cause the water to form into simple shapes and animate at your direction. This change lasts for 1 hour. \n You change the water’s color or opacity. The water must be changed in the same way throughout. This change lasts for 1 hour. \n You freeze the water, provided that there are no creatures in it. The water unfreezes in 1 hour. \n If you cast this spell multiple times, you can have no more than two of its non-instantaneous effects active at a time, and you can dismiss such an effect as an action."
                                                    },
                                    "shillelagh": {
                                                        "name": "Shillelagh",
                                                        "school": "Transmutation",
                                                        "casting time": "1 Bonus Action",
                                                        "range": "Touch",
                                                        "duration": "1 minute",
                                                        "components": "Verbal, Somatic, Material",
                                                        "description": "The wood of a club or quarterstaff you are holding is imbued with nature’s power. For the duration, you can use your spellcasting ability instead of Strength for the attack and damage rolls of melee attacks using that weapon, and the weapon’s damage die becomes a d8. The weapon also becomes magical, if it isn’t already. The spell ends if you cast it again or if you let go of the weapon."
                                                    },
                                    "shocking grasp": {
                                                        "name": "Shocking Grasp",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "Touch",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "Lightning springs from your hand to deliver a shock to a creature you try to touch. Make a melee spell attack against the target. You have advantage on the attack roll if the target is wearing armor made of metal. On a hit, the target takes 1d8 lightning damage, and it can’t take reactions until the start of its next turn. \n \n **At Higher Levels.** The spell’s damage increases by 1d8 when you reach 5th level (2d8), 11th level (3d8), and 17th level (4d8)."
                                                    },
                                    "spare the dying": {
                                                        "name": "Spare the Dying",
                                                        "school": "Necromancy",
                                                        "casting time": "1 Action",
                                                        "range": "Touch",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "You touch a living creature that has 0 hit points. The creature becomes stable. This spell has no effect on undead or constructs."
                                                    },
                                    "sword burst": {
                                                        "name": "Sword Burst",
                                                        "school": "Conjuration",
                                                        "casting time": "1 Action",
                                                        "range": "Self (5-foot radius)",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal",
                                                        "description": "You create a momentary circle of spectral blades that sweep around you. All other creatures within 5 feet of you must succeed on a Dexterity saving throw or take 1d6 force damage. \n \n **At Higher Levels.** This spell's damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6)."
                                                    },
                                    "thaumaturgy": {
                                                        "name": "Thaumaturgy",
                                                        "school": "Transmutation",
                                                        "casting time": "1 Action",
                                                        "range": "30 feet",
                                                        "duration": "Up to 1 minute",
                                                        "components": "Verbal",
                                                        "description": "You manifest a minor wonder, a sign of supernatural power, within range. You create one of the following magical effects within range: \n \n Your voice booms up to three times as loud as normal for 1 minute. \n You cause flames to flicker, brighten, dim, or change color for 1 minute.\n You cause harmless tremors in the ground for 1 minute.\n You create an instantaneous sound that originates from a point of your choice within range, such as a rumble of thunder, the cry of a raven, or ominous whispers.\n You instantaneously cause an unlocked door or window to fly open or slam shut.\n You alter the appearance of your eyes for 1 minute.\n If you cast this spell multiple times, you can have up to three of its 1-minute effects active at a time, and you can dismiss such an effect as an action."
                                                    },
                                    "thorn whip": {
                                                        "name": "Thorn Whip",
                                                        "school": "Transmutation",
                                                        "casting time": "1 Action",
                                                        "range": "30 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic, Material",
                                                        "description": "You create a long, vine-like whip covered in thorns that lashes out at your command toward a creature in range. Make a melee spell attack against the target. If the attack hits, the creature takes 1d6 piercing damage, and if the creature is Large or smaller, you pull the creature up to 10 feet closer to you. \n \n **At Higher Levels.** This spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6)."
                                                    },
                                    "thunderclap": {
                                                        "name": "Thunderclap",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "Self (5-foot radius)",
                                                        "duration": "Instantaneous",
                                                        "components": "Somatic",
                                                        "description": "You create a burst of thunderous sound, which can be heard 100 feet away. Each creature other than you within 5 feet of you must make a Constitution saving throw. On a failed save, the creature takes 1d6 thunder damage.\n \n **At Higher Levels.** The spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6)."
                                                    },
                                    "toll the dead": {
                                                        "name": "Toll the Dead",
                                                        "school": "Necromancy",
                                                        "casting time": "1 Action",
                                                        "range": "60 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Somatic",
                                                        "description": "You point at one creature you can see within range, and the sound of a dolorous bell fills the air around it for a moment. The target must succeed on a Wisdom saving throw or take 1d8 necrotic damage. If the target is missing any of its hit points, it instead takes 1d12 necrotic damage.\n \n **At Higher Levels.** The spell’s damage increases by one die when you reach 5th level (2d8 or 2d12), 11th level (3d8 or 3d12), and 17th level (4d8 or 4d12)."
                                                    },
                                    "true strike": {
                                                       "name": "True Strike",
                                                       "school": "Divination",
                                                       "casting time": "1 Action",
                                                       "range": "30 feet",
                                                       "duration": "Concentration up to 1 round",
                                                       "components": "Somatic",
                                                       "description": "You extend your hand and point a finger at a target in range. Your magic grants you a brief insight into the target’s defenses. On your next turn, you gain advantage on your first attack roll against the target, provided that this spell hasn’t ended."
                                                   },
                                    "vicious mockery": {
                                                        "name": "Vicious Mockery",
                                                        "school": "Enchantment",
                                                        "casting time": "1 Action",
                                                        "range": "60 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal",
                                                        "description": "You unleash a string of insults laced with subtle enchantments at a creature you can see within range. If the target can hear you (though it need not understand you), it must succeed on a Wisdom saving throw or take 1d4 psychic damage and have disadvantage on the next attack roll it makes before the end of its next turn. \n \n **At Higher Levels.** This spell’s damage increases by 1d4 when you reach 5th level (2d4), 11th level (3d4), and 17th level (4d4)."
                                                    },
                                    "virtue": {
                                                  "name": "Virtue",
                                                  "school": "Abjuration",
                                                  "casting time": "1 Action",
                                                  "range": "Touch",
                                                  "duration": "1 round",
                                                  "components": "Verbal, Somatic",
                                                  "description": "You touch one creature, imbuing it with vitality. If the target has at least 1 hit point, it gains a number of temporary hit points equal to 1d4 + your spellcasting ability modifier. The temporary hit points are lost when the spell ends."
                                              },
                                    "word of radiance":{ 
                                                        "name": "Word of Radiance",
                                                        "school": "Evocation",
                                                        "casting time": "1 Action",
                                                        "range": "5 feet",
                                                        "duration": "Instantaneous",
                                                        "components": "Verbal, Material",
                                                        "description": "You utter a divine word, and burning radiance erupts from you. Each creature of your choice that you can see within range must succeed on a Constitution saving throw or take 1d6 radiant damage.\n \n **At Higher Levels.** The spell’s damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6)."
                                                     },
                                    # 1st level spells

                                                        "absorb elements": {
                                                            "name": "Absorb Elements",
                                                            "school": "Abjuration",
                                                            "casting time": "1 Reaction",
                                                            "range": "Self",
                                                            "duration": "1 round",
                                                            "components": "Verbal, Somatic",
                                                            "description": "The spell allows you to harness the energy of incoming attacks to briefly enhance your defenses. When you take acid, cold, fire, lightning, or thunder damage, you can use your reaction to absorb some of that energy. You have resistance to the triggering damage type until the start of your next turn. Also, the first time you hit with a melee attack on your next turn, the target takes an extra 1d6 damage of the triggering type."
                                                        },
                                                        "acid stream": {
                                                            "name": "Acid Stream",
                                                            "school": "Evocation",
                                                            "casting time": "1 Action",
                                                            "range": "Self (30-foot line)",
                                                            "duration": "Concentration, up to 1 minute",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "You unleash a stream of acid in a line 30 feet long and 5 feet wide. Each creature in the line must make a Dexterity saving throw, taking 3d6 acid damage on a failed save, or half as much damage on a successful one. On each of your turns for the duration, you can use your action to deal 3d6 acid damage to creatures in the line."
                                                        },
                                                        "alarm": {
                                                            "name": "Alarm",
                                                            "school": "Abjuration",
                                                            "casting time": "1 Minute/Ritual",
                                                            "range": "30 feet",
                                                            "duration": "8 Hours",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "You set an alarm against unwanted intrusion. Choose a door, a window, or an area within range. Until the spell ends, an alarm alerts you whenever a Tiny or larger creature touches or enters the warded area. When you cast the spell, you can designate creatures that won't set off the alarm."
                                                        },
                                                        "animal friendship": {
                                                            "name": "Animal Friendship",
                                                            "school": "Enchantment",
                                                            "casting time": "1 Action",
                                                            "range": "30 feet",
                                                            "duration": "24 hours",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "This spell lets you convince a beast that you mean it no harm. Choose a beast that you can see within range. It must see and hear you. If the beast’s Intelligence is 4 or higher, the spell fails. Otherwise, the beast must succeed on a Wisdom saving throw or be charmed by you for the spell's duration. If you or one of your companions harms the target, the spell ends."
                                                        },
                                                        "arcane weapon": {
                                                            "name": "Arcane Weapon",
                                                            "school": "Transmutation",
                                                            "casting time": "1 Bonus Action",
                                                            "range": "Self",
                                                            "duration": "Concentration, up to 1 hour",
                                                            "components": "Verbal, Somatic",
                                                            "description": "You channel arcane energy into a weapon you're holding. For the duration, the weapon becomes a magic weapon with a +1 bonus to attack rolls and deals an extra 1d6 damage of a type chosen by you when you cast the spell. The spell ends if you drop the weapon or cast it again."
                                                        },
                                                        "armor of agathys": {
                                                            "name": "Armor of Agathys",
                                                            "school": "Abjuration",
                                                            "casting time": "1 Action",
                                                            "range": "Self",
                                                            "duration": "1 hour",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "A protective magical force surrounds you, manifesting as a spectral frost. You gain 5 temporary hit points for the duration. If a creature hits you with a melee attack while you have these hit points, the creature takes 5 cold damage. After absorbing damage, the spell ends."
                                                        },
                                                        "arms of hadar": {
                                                            "name": "Arms of Hadar",
                                                            "school": "Conjuration",
                                                            "casting time": "1 Action",
                                                            "range": "Self (10-foot radius)",
                                                            "duration": "Instantaneous",
                                                            "components": "Verbal, Somatic",
                                                            "description": "You invoke the power of Hadar, the Dark Hunger. Tendrils of dark energy erupt from you and batter all creatures within 10 feet of you. Each creature in that area must make a Strength saving throw. On a failed save, the creature takes 2d6 necrotic damage and can't take reactions until its next turn."
                                                        },
                                                        "bane": {
                                                            "name": "Bane",
                                                            "school": "Enchantment",
                                                            "casting time": "1 Action",
                                                            "range": "30 feet",
                                                            "duration": "Concentration, up to 1 minute",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "You curse up to three creatures of your choice within range. Whenever a target that fails its saving throw makes an attack roll or a saving throw before the spell ends, it must roll a d4 and subtract the number rolled from the attack roll or saving throw."
                                                        },
                                                        "beast bond": {
                                                            "name": "Beast Bond",
                                                            "school": "Divination",
                                                            "casting time": "1 Action",
                                                            "range": "Touch",
                                                            "duration": "Concentration, up to 1 minute",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "This spell lets you establish a telepathic link with one beast you touch that is friendly to you or charmed by you. The link is active for the duration or until you use your action to dismiss it. While linked, the beast can understand your telepathic messages, and you can issue commands to it."
                                                        },
                                                        "bless": {
                                                            "name": "Bless",
                                                            "school": "Enchantment",
                                                            "casting time": "1 Action",
                                                            "range": "30 feet",
                                                            "duration": "Concentration, up to 1 minute",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "You bless up to three creatures of your choice within range. Whenever a target makes an attack roll or a saving throw before the spell ends, it can roll a d4 and add the number rolled to the attack roll or saving throw."
                                                        },
                                                        "burning hands": {
                                                            "name": "Burning Hands",
                                                            "school": "Evocation",
                                                            "casting time": "1 Action",
                                                            "range": "Self (15-foot cone)",
                                                            "duration": "Instantaneous",
                                                            "components": "Verbal, Somatic",
                                                            "description": "As you hold your hands with thumbs touching and fingers spread, a thin sheet of flames shoots forth from your outstretched fingertips. Each creature in a 15-foot cone must make a Dexterity saving throw. A creature takes 3d6 fire damage on a failed save, or half as much damage on a successful one."
                                                        },
                                                        "catapult": {
                                                            "name": "Catapult",
                                                            "school": "Transmutation",
                                                            "casting time": "1 Action",
                                                            "range": "60 feet",
                                                            "duration": "Instantaneous",
                                                            "components": "Somatic",
                                                            "description": "Choose one object weighing 1 to 5 pounds within range that isn't being worn or carried. The object flies in a straight line up to 90 feet in a direction you choose before falling to the ground, stopping early if it impacts against a solid surface. If the object would strike a creature, that creature must make a Dexterity saving throw."
                                                        },
                                                        "cause fear": {
                                                            "name": "Cause Fear",
                                                            "school": "Necromancy",
                                                            "casting time": "1 Action",
                                                            "range": "60 feet",
                                                            "duration": "Concentration, up to 1 minute",
                                                            "components": "Verbal, Somatic",
                                                            "description": "You awaken the sense of mortality in one creature you can see within range. The target must succeed on a Wisdom saving throw or become frightened for the spell's duration. The frightened target can repeat the saving throw at the end of each of its turns, ending the effect on itself on a success."
                                                        },
                                                        "ceremony": {
                                                            "name": "Ceremony",
                                                            "school": "Evocation",
                                                            "casting time": "1 Action/Ritual",
                                                            "range": "Touch",
                                                            "duration": "Instantaneous",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "You perform a special religious ceremony that is infused with magic. Choose one of the following rites, the target, and a willing creature within range who shares your alignment. The target becomes under the effects of the chosen rite."
                                                        },
                                                        "chaos bolt": {
                                                            "name": "Chaos Bolt",
                                                            "school": "Evocation",
                                                            "casting time": "1 Action",
                                                            "range": "120 feet",
                                                            "duration": "Instantaneous",
                                                            "components": "Verbal, Somatic",
                                                            "description": "You hurl an undulating, warbling mass of chaotic energy at one creature in range. Make a ranged spell attack against the target. On a hit, the target takes 2d8 + 1d6 damage of a type chosen at random from acid, cold, fire, lightning, poison, or thunder."
                                                        },
                                                        "charm person": {
                                                            "name": "Charm Person",
                                                            "school": "Enchantment",
                                                            "casting time": "1 Action",
                                                            "range": "30 feet",
                                                            "duration": "1 hour",
                                                            "components": "Verbal, Somatic",
                                                            "description": "You attempt to charm a humanoid you can see within range. It must make a Wisdom saving throw, and does so with advantage if you or your companions are fighting it. If it fails the saving throw, it is charmed by you until the spell ends or until you or your companions do anything harmful to it."
                                                        },
                                                        "chromatic orb": {
                                                            "name": "Chromatic Orb",
                                                            "school": "Evocation",
                                                            "casting time": "1 Action",
                                                            "range": "90 feet",
                                                            "duration": "Instantaneous",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "You hurl a 4-inch-diameter sphere of energy at a creature you can see within range. Make a ranged spell attack against the target. On a hit, the target takes 3d8 damage. The damage type is determined by the type of orb you use: acid, cold, fire, lightning, poison, or thunder."
                                                        },
                                                        "color spray": {
                                                            "name": "Color Spray",
                                                            "school": "Illusion",
                                                            "casting time": "1 Action",
                                                            "range": "Self (15-foot cone)",
                                                            "duration": "1 round",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "A dazzling array of flashing, colored light springs from your hand. Roll 6d10; the total is how many hit points of creatures this spell can affect. Creatures in a 15-foot cone originating from you are affected in ascending order of their current hit points."
                                                        },
                                                        "command": {
                                                            "name": "Command",
                                                            "school": "Enchantment",
                                                            "casting time": "1 Action",
                                                            "range": "60 feet",
                                                            "duration": "1 round",
                                                            "components": "Verbal",
                                                            "description": "You speak a one-word command to a creature you can see within range. The target must succeed on a Wisdom saving throw or follow the command on its next turn. The spell has no effect if the target is undead, if it doesn't understand your language, or if your command is directly harmful to it."
                                                        },
                                                        "compelled duel": {
                                                            "name": "Compelled Duel",
                                                            "school": "Enchantment",
                                                            "casting time": "1 Bonus Action",
                                                            "range": "30 feet",
                                                            "duration": "Concentration, up to 1 minute",
                                                            "components": "Verbal",
                                                            "description": "You attempt to compel a creature into a duel. One creature you can see within range must make a Wisdom saving throw. On a failed save, the creature is drawn to you, compelled by your divine demand. For the duration, it has disadvantage on attack rolls against creatures other than you, and must make a Wisdom saving throw each time it attempts to move to a space that is more than 30 feet away from you."
                                                        },
                                                        "comprehend languages": {
                                                            "name": "Comprehend Languages",
                                                            "school": "Divination",
                                                            "casting time": "1 Action/Ritual",
                                                            "range": "Self",
                                                            "duration": "1 hour",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "You understand the literal meaning of any spoken language that you hear. You also understand any written language that you see, but you must be touching the surface on which the words are written. It takes about 1 minute to read one page of text."
                                                        },
                                                        "create or destroy water": {
                                                            "name": "Create or Destroy Water",
                                                            "school": "Transmutation",
                                                            "casting time": "1 Action",
                                                            "range": "30 feet",
                                                            "duration": "Instantaneous",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "You either create or destroy water within 30 feet of you. You can create up to 10 gallons of clean water within containers or on the ground, or destroy the same amount of water in open containers or a 30-foot cube."
                                                        },
                                                        "cure wounds": {
                                                            "name": "Cure Wounds",
                                                            "school": "Evocation",
                                                            "casting time": "1 Action",
                                                            "range": "Touch",
                                                            "duration": "Instantaneous",
                                                            "components": "Verbal, Somatic",
                                                            "description": "A creature you touch regains a number of hit points equal to 1d8 + your spellcasting ability modifier. This spell has no effect on undead or constructs."
                                                        },
                                                        "detect evil and good": {
                                                            "name": "Detect Evil and Good",
                                                            "school": "Divination",
                                                            "casting time": "1 Action",
                                                            "range": "Self",
                                                            "duration": "Concentration, up to 10 minutes",
                                                            "components": "Verbal, Somatic",
                                                            "description": "You know if there is an aberration, celestial, elemental, fey, fiend, or undead within 30 feet of you, as well as where the creature is located. Similarly, you know if there is a place or object within 30 feet of you that has been magically consecrated or desecrated."
                                                        },
                                                        "detect magic": {
                                                            "name": "Detect Magic",
                                                            "school": "Divination",
                                                            "casting time": "1 Action/Ritual",
                                                            "range": "Self",
                                                            "duration": "Concentration, up to 10 minutes",
                                                            "components": "Verbal, Somatic",
                                                            "description": "For the duration, you sense the presence of magic within 30 feet of you. If you sense magic in this way, you can use your action to see a faint aura around any visible creature or object in the area that bears magic, and you learn its school of magic, if any."
                                                        },
                                                        "detect poison and disease": {
                                                            "name": "Detect Poison and Disease",
                                                            "school": "Divination",
                                                            "casting time": "1 Action/Ritual",
                                                            "range": "Self",
                                                            "duration": "Concentration, up to 10 minutes",
                                                            "components": "Verbal, Somatic, Material",
                                                            "description": "For the duration, you can sense the presence and location of poisons, poisonous creatures, and diseases within 30 feet of you. You also identify the kind of poison, poisonous creature, or disease in each case."
                                                        },
                                                        "disguise self": {
                                                            "name": "Disguise Self",
                                                            "school": "Illusion",
                                                            "casting time": "1 Action",
                                                            "range": "Self",
                                                            "duration": "1 hour",
                                                            "components": "Verbal, Somatic",
                                                            "description": "You make yourself—including your clothing, armor, weapons, and other belongings on your person—look different until the spell ends or until you use your action to dismiss it. You can seem 1 foot shorter or taller, thin, fat, or in between. You can't change your body type, so you must adopt a form that has the same basic arrangement of limbs."
                                                        },
                                                        "dissonant whispers": {
                                                            "name": "Dissonant Whispers",
                                                            "school": "Enchantment",
                                                            "casting time": "1 Action",
                                                            "range": "60 feet",
                                                            "duration": "Instantaneous",
                                                            "components": "Verbal",
                                                            "description": "You whisper a discordant melody that only one creature of your choice within range can hear, wracking it with terrible pain. The target must make a Wisdom saving throw. On a failed save, it takes 3d6 psychic damage and must immediately use its reaction, if available, to move as far as its speed allows away from you."
                                                        },
                                                        "distort value": {
                                                            "name": "Distort Value",
                                                            "school": "Illusion",
                                                            "casting time": "1 Minute",
                                                            "range": "Touch",
                                                            "duration": "8 hours",
                                                            "components": "Verbal",
                                                            "description": "You change the way a target perceives the value of an object. The object appears to be worth more or less than it is, based on your instructions. For example, you could make a copper piece look like a gold piece, or vice versa."
                                                        },
                                                        "divine favor": {
                                                            "name": "Divine Favor",
                                                            "school": "Evocation",
                                                            "casting time": "1 Bonus Action",
                                                            "range": "Self",
                                                            "duration": "Concentration, up to 1 minute",
                                                            "components": "Verbal, Somatic",
                                                            "description": "Your prayer empowers you with divine radiance. Your weapon attacks deal an extra 1d4 radiant damage on a hit for the duration."
                                                        },
                                                        "earth tremor": {
                                                            "name": "Earth Tremor",
                                                            "school": "Evocation",
                                                            "casting time": "1 Action",
                                                            "range": "Self (10-foot radius)",
                                                            "duration": "Instantaneous",
                                                            "components": "Verbal, Somatic",
                                                            "description": "You cause a tremor in the ground within range. Each creature other than you in that area must make a Dexterity saving throw. On a failed save, a creature takes 1d6 bludgeoning damage and is knocked prone. If the ground in the area is loose earth or stone, it becomes difficult terrain until cleared."
                                                        },
                                                        "ensnaring strike": {
                                                            "name": "Ensnaring Strike",
                                                            "school": "Conjuration",
                                                            "casting time": "1 Bonus Action",
                                                            "range": "Self",
                                                            "duration": "Concentration, up to 1 minute",
                                                            "components": "Verbal",
                                                            "description": "The next time you hit a creature with a weapon attack before the spell ends, a writhing mass of thorny vines appears at the point of impact, and the target must succeed on a Strength saving throw or be restrained by the magical vines until the spell ends."
                                                        },
                                        "entangle": {
                                            "name": "Entangle",
                                            "school": "Conjuration",
                                            "casting time": "1 Action",
                                            "range": "90 feet",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal, Somatic",
                                            "description": "You cause grasping weeds and vines to sprout from the ground in a 20-foot square starting from a point within range. For the duration, these plants turn the ground in the area into difficult terrain. A creature in the area when you cast the spell must succeed on a Strength saving throw or be restrained by the entangling plants until the spell ends."
                                        },
                                        "expeditious retreat": {
                                            "name": "Expeditious Retreat",
                                            "school": "Transmutation",
                                            "casting time": "1 Bonus Action",
                                            "range": "Self",
                                            "duration": "Concentration, up to 10 minutes",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "This spell allows you to move at an incredible pace. When you cast this spell, and then as a bonus action on each of your turns until the spell ends, you can take the Dash action."
                                        },
                                        "faerie fire": {
                                            "name": "Faerie Fire",
                                            "school": "Evocation",
                                            "casting time": "1 Action",
                                            "range": "60 feet",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal",
                                            "description": "Each object in a 20-foot cube within range is outlined in blue, green, or violet light (your choice). Any creature in the area when the spell is cast is also outlined in light if it fails a Dexterity saving throw. For the duration, objects and affected creatures shed dim light in a 10-foot radius."
                                        },
                                        "false life": {
                                            "name": "False Life",
                                            "school": "Necromancy",
                                            "casting time": "1 Action",
                                            "range": "Self",
                                            "duration": "1 hour",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You gain 1d4 + 4 temporary hit points for the duration."
                                        },
                                        "feather fall": {
                                            "name": "Feather Fall",
                                            "school": "Transmutation",
                                            "casting time": "1 Reaction",
                                            "range": "60 feet",
                                            "duration": "1 minute",
                                            "components": "Verbal, Material",
                                            "description": "Choose up to five falling creatures within range. A falling creature's rate of descent slows to 60 feet per round until the spell ends. If the creature lands before the spell ends, it takes no falling damage and can land on its feet, and the spell ends for that creature."
                                        },
                                        "find familiar": {
                                            "name": "Find Familiar",
                                            "school": "Conjuration",
                                            "casting time": "1 Hour/Ritual",
                                            "range": "10 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You gain the service of a familiar, a spirit that takes an animal form you choose: bat, cat, crab, frog (toad), hawk, lizard, octopus, owl, poisonous snake, fish (quipper), rat, raven, sea horse, spider, or weasel."
                                        },
                                        "fog cloud": {
                                            "name": "Fog Cloud",
                                            "school": "Conjuration",
                                            "casting time": "1 Action",
                                            "range": "120 feet",
                                            "duration": "Concentration, up to 1 hour",
                                            "components": "Verbal, Somatic",
                                            "description": "You create a 20-foot-radius sphere of fog centered on a point within range. The sphere spreads around corners, and its area is heavily obscured. It lasts for the duration or until a wind of moderate or greater speed (at least 10 miles per hour) disperses it."
                                        },
                                        "frost fingers": {
                                            "name": "Frost Fingers",
                                            "school": "Evocation",
                                            "casting time": "1 Action",
                                            "range": "Self (15-foot cone)",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic",
                                            "description": "A blast of cold air erupts from your hands. Each creature in a 15-foot cone must make a Dexterity saving throw. On a failed save, a creature takes 2d6 cold damage, and its speed is reduced by 10 feet until the start of your next turn."
                                        },
                                        "gift of alacrity": {
                                            "name": "Gift of Alacrity",
                                            "school": "Divination",
                                            "casting time": "1 Minute",
                                            "range": "Touch",
                                            "duration": "8 hours",
                                            "components": "Verbal, Somatic",
                                            "description": "You touch a willing creature, granting it the ability to react with supernatural speed. The creature gains a +1d4 bonus to its initiative rolls for the duration."
                                        },
                                        "goodberry": {
                                            "name": "Goodberry",
                                            "school": "Transmutation",
                                            "casting time": "1 Action",
                                            "range": "Touch",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "Up to ten berries appear in your hand and are infused with magic for the duration. A creature can use its action to eat one berry. Eating a berry restores 1 hit point, and the berry provides enough nourishment to sustain a creature for one day."
                                        },
                                        "grease": {
                                            "name": "Grease",
                                            "school": "Conjuration",
                                            "casting time": "1 Action",
                                            "range": "60 feet",
                                            "duration": "1 minute",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "Slick grease covers the ground in a 10-foot square centered on a point within range and turns it into difficult terrain for the duration. When the grease appears, each creature standing in its area must succeed on a Dexterity saving throw or fall prone."
                                        },
                                        "guiding bolt": {
                                            "name": "Guiding Bolt",
                                            "school": "Evocation",
                                            "casting time": "1 Action",
                                            "range": "120 feet",
                                            "duration": "1 round",
                                            "components": "Verbal, Somatic",
                                            "description": "A flash of light streaks toward a creature of your choice within range. Make a ranged spell attack against the target. On a hit, the target takes 4d6 radiant damage, and the next attack roll made against this target before the end of your next turn has advantage."
                                        },
                                        "guiding hand": {
                                            "name": "Guiding Hand (UA)",
                                            "school": "Divination",
                                            "casting time": "1 Minute/Ritual",
                                            "range": "5 feet",
                                            "duration": "Concentration, up to 8 hours",
                                            "components": "Verbal, Somatic",
                                            "description": "You create a magical hand that you can control. The hand is intangible and cannot attack, activate magic items, or carry more than 10 pounds. It remains for the duration or until you dismiss it as an action."
                                        },
                                        "hail of thorns": {
                                            "name": "Hail of Thorns",
                                            "school": "Conjuration",
                                            "casting time": "1 Bonus Action",
                                            "range": "Self",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal",
                                            "description": "The next time you hit a creature with a ranged weapon attack before this spell ends, the target and each creature within 5 feet of it must make a Dexterity saving throw. A creature takes 1d10 piercing damage on a failed save, or half as much damage on a successful one."
                                        },
                                        "healing elixir": {
                                            "name": "Healing Elixir (UA)",
                                            "school": "Conjuration",
                                            "casting time": "1 Minute",
                                            "range": "Self",
                                            "duration": "24 hours",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You create a vial of liquid suffused with healing energy. The potion can be consumed as an action to restore hit points equal to 2d4 + your spellcasting ability modifier."
                                        },
                                        "healing word": {
                                            "name": "Healing Word",
                                            "school": "Evocation",
                                            "casting time": "1 Bonus Action",
                                            "range": "60 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal",
                                            "description": "A creature of your choice that you can see within range regains hit points equal to 1d4 + your spellcasting ability modifier."
                                        },
                                        "hellish rebuke": {
                                            "name": "Hellish Rebuke",
                                            "school": "Evocation",
                                            "casting time": "1 Reaction",
                                            "range": "60 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic",
                                            "description": "You point your finger, and the creature that damaged you is momentarily surrounded by hellish flames. The creature must make a Dexterity saving throw. It takes 2d10 fire damage on a failed save, or half as much damage on a successful one."
                                        },
                                        "heroism": {
                                            "name": "Heroism",
                                            "school": "Enchantment",
                                            "casting time": "1 Action",
                                            "range": "Touch",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal, Somatic",
                                            "description": "A willing creature you touch is imbued with bravery. Until the spell ends, the creature is immune to being frightened and gains temporary hit points equal to your spellcasting ability modifier at the start of each of its turns. When the spell ends, the target loses any remaining temporary hit points from this spell. **At Higher Levels.** When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st."
                                        },
                                        "hex spell": {
                                            "name": "Hex",
                                            "school": "Enchantment",
                                            "casting time": "1 Bonus Action",
                                            "range": "90 feet",
                                            "duration": "Concentration, up to 1 hour",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You place a curse on a creature that you can see within range. Until the spell ends, you deal an extra 1d6 necrotic damage to the target whenever you hit it with an attack."
                                        },
                                        "hunters mark": {
                                            "name": "Hunter's Mark",
                                            "school": "Divination",
                                            "casting time": "1 Bonus Action",
                                            "range": "90 feet",
                                            "duration": "Concentration, up to 1 hour",
                                            "components": "Verbal",
                                            "description": "You choose a creature you can see within range and mystically mark it as your quarry. Until the spell ends, you deal an extra 1d6 damage to the target whenever you hit it with a weapon attack."
                                        },
                                        "ice knife": {
                                            "name": "Ice Knife",
                                            "school": "Conjuration",
                                            "casting time": "1 Action",
                                            "range": "60 feet",
                                            "duration": "Instantaneous",
                                            "components": "Somatic, Material",
                                            "description": "You create a shard of ice and fling it at one creature within range. Make a ranged spell attack against the target. On a hit, the target takes 1d10 piercing damage. Hit or miss, the shard explodes, and each creature within 5 feet of the point where the ice exploded must succeed on a Dexterity saving throw or take 2d6 cold damage."
                                        },
                                        "id insinuation": {
                                            "name": "Id Insinuation (UA)",
                                            "school": "Enchantment",
                                            "casting time": "1 Action",
                                            "range": "60 feet",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal, Somatic",
                                            "description": "You insinuate confusing thoughts into the mind of one creature you can see within range. The target must succeed on an Intelligence saving throw or take 2d6 psychic damage and have disadvantage on the next attack roll it makes before the end of its next turn."
                                        },
                                        "identify": {
                                            "name": "Identify",
                                            "school": "Divination",
                                            "casting time": "1 Minute/Ritual",
                                            "range": "Touch",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You choose one object that you must touch throughout the casting of the spell. If it is a magic item or some other magic-imbued object, you learn its properties and how to use them, whether it requires attunement to use, and how many charges it has, if any."
                                        },
                                        "illusory script": {
                                            "name": "Illusory Script",
                                            "school": "Illusion",
                                            "casting time": "1 Minute/Ritual",
                                            "range": "Touch",
                                            "duration": "10 days",
                                            "components": "Somatic, Material",
                                            "description": "You write on parchment, paper, or some other suitable writing material and imbue it with a potent illusion that lasts for the duration."
                                        },
                                        "infallible relay": {
                                            "name": "Infallible Relay (UA)",
                                            "school": "Divination",
                                            "casting time": "1 Minute",
                                            "range": "Self",
                                            "duration": "Concentration, up to 10 minutes",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You create a psychic link between yourself and a willing creature within range. For the duration, you can use your action to send telepathic messages to the target, which it can respond to using a similar action. The link remains until the spell ends or until you use this action to end it."
                                        },
                                        "inflict wounds": {
                                            "name": "Inflict Wounds",
                                            "school": "Necromancy",
                                            "casting time": "1 Action",
                                            "range": "Touch",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic",
                                            "description": "Make a melee spell attack against a creature you can reach. On a hit, the target takes 3d10 necrotic damage."
                                        },
                                        "jims magic missile": {
                                            "name": "Jim's Magic Missile",
                                            "school": "Evocation",
                                            "casting time": "1 Action",
                                            "range": "120 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You create three glowing darts of magical force. Each dart hits a creature of your choice that you can see within range. A dart deals 1d4 + 1 force damage to its target. The darts all strike simultaneously, and you can direct them to hit one creature or several."
                                        },
                                        "jump spell": {
                                            "name": "Jump",
                                            "school": "Transmutation",
                                            "casting time": "1 Action",
                                            "range": "Touch",
                                            "duration": "1 minute",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You touch a creature. The creature's jump distance is tripled until the spell ends."
                                        },
                                        "longstrider": {
                                            "name": "Longstrider",
                                            "school": "Transmutation",
                                            "casting time": "1 Action",
                                            "range": "Touch",
                                            "duration": "1 hour",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You touch a creature. The target's speed increases by 10 feet until the spell ends."
                                        },
                                        "mage armor": {
                                            "name": "Mage Armor",
                                            "school": "Abjuration",
                                            "casting time": "1 Action",
                                            "range": "Touch",
                                            "duration": "8 hours",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You touch a willing creature who isn't wearing armor, and a protective magical force surrounds it until the spell ends. The target's base AC becomes 13 + its Dexterity modifier."
                                        },
                                        "magic missile": {
                                            "name": "Magic Missile",
                                            "school": "Evocation",
                                            "casting time": "1 Action",
                                            "range": "120 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic",
                                            "description": "You create three glowing darts of magical force. Each dart hits a creature of your choice that you can see within range. A dart deals 1d4 + 1 force damage to its target. The darts all strike simultaneously and are unaffected by any other spell effects."
                                        },
                                        "magnify gravity": {
                                            "name": "Magnify Gravity",
                                            "school": "Transmutation",
                                            "casting time": "1 Action",
                                            "range": "60 feet",
                                            "duration": "1 round",
                                            "components": "Verbal, Somatic",
                                            "description": "You alter the weight of one object or creature you can see within range, increasing its weight up to twice its normal weight until the spell ends."
                                        },
                                        "protection from evil and good": {
                                            "name": "Protection from Evil and Good",
                                            "school": "Abjuration",
                                            "casting time": "1 Action",
                                            "range": "Touch",
                                            "duration": "Concentration, up to 10 minutes",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "Until the spell ends, one willing creature you touch is protected against certain types of creatures: aberrations, celestials, elementals, fey, fiends, and undead."
                                        },
                                        "puppet": {
                                            "name": "Puppet (UA)",
                                            "school": "Enchantment",
                                            "casting time": "1 Action",
                                            "range": "120 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal",
                                            "description": "You attempt to manipulate a creature's emotions. Choose one creature you can see within range. The target must succeed on a Wisdom saving throw or it becomes charmed by you for the duration."
                                        },
                                        "purify food and drink": {
                                            "name": "Purify Food and Drink",
                                            "school": "Transmutation",
                                            "casting time": "1 Action/Ritual",
                                            "range": "10 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic",
                                            "description": "All nonmagical food and drink within a 5-foot-radius sphere centered on a point of your choice within range is purified and rendered free of poison and disease."
                                        },
                                        "ray of sickness": {
                                            "name": "Ray of Sickness",
                                            "school": "Necromancy",
                                            "casting time": "1 Action",
                                            "range": "60 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic",
                                            "description": "A ray of sickening greenish energy lashes out toward a creature within range. Make a ranged spell attack against the target. On a hit, the target takes 2d8 poison damage and must make a Constitution saving throw, taking 1d8 poison damage on a failed save, or half as much damage on a successful one."
                                        },
                                        "remote access": {
                                            "name": "Remote Access (UA)",
                                            "school": "Transmutation",
                                            "casting time": "1 Action",
                                            "range": "120 feet",
                                            "duration": "10 minutes",
                                            "components": "Verbal, Somatic",
                                            "description": "You access a creature's mind and exchange memories with it. You can communicate telepathically with one willing creature you can see within range."
                                        },
                                        "sanctuary": {
                                            "name": "Sanctuary",
                                            "school": "Abjuration",
                                            "casting time": "1 Bonus Action",
                                            "range": "30 feet",
                                            "duration": "1 minute",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You ward a creature within range against attack. Until the spell ends, any creature who targets the warded creature with an attack or a harmful spell must first make a Wisdom saving throw."
                                        },
                                        "searing smite": {
                                            "name": "Searing Smite",
                                            "school": "Evocation",
                                            "casting time": "1 Bonus Action",
                                            "range": "Self",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal",
                                            "description": "The first time you hit a creature with a melee weapon attack during the spell's duration, your weapon flares with white-hot intensity, and the attack deals an extra 1d6 fire damage to the target, and it ignites in flames."
                                        },
                                        "sense emotion": {
                                            "name": "Sense Emotion (UA)",
                                            "school": "Divination",
                                            "casting time": "1 Action",
                                            "range": "Self",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal, Somatic",
                                            "description": "You detect the basic emotions of a creature. For the duration, you can sense the basic emotions of any creature you can see within 30 feet of you. You can sense whether a creature is feeling happy, sad, angry, or frightened."
                                        },
                                        "shield": {
                                            "name": "Shield",
                                            "school": "Abjuration",
                                            "casting time": "1 Reaction",
                                            "range": "Self",
                                            "duration": "1 round",
                                            "components": "Verbal, Somatic",
                                            "description": "An invisible barrier of magical force appears and protects you. Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from magic missile."
                                        },
                                        "shield of faith": {
                                            "name": "Shield of Faith",
                                            "school": "Abjuration",
                                            "casting time": "1 Bonus Action",
                                            "range": "60 feet",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "A shimmering field appears and surrounds a creature of your choice within range, granting it a +2 bonus to AC for the duration."
                                        },
                                        "silent image": {
                                            "name": "Silent Image",
                                            "school": "Illusion",
                                            "casting time": "1 Action",
                                            "range": "60 feet",
                                            "duration": "Concentration, up to 10 minutes",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You create the image of an object, a creature, or some other visible phenomenon that is no larger than a 15-foot cube. The image appears at a spot within range and lasts for the duration."
                                        },
                                        "silvery barbs": {
                                            "name": "Silvery Barbs",
                                            "school": "Enchantment",
                                            "casting time": "1 Reaction",
                                            "range": "60 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal",
                                            "description": "You unleash a torrent of conflicting desires in the mind of a creature you can see within range. The target must make a Wisdom saving throw. On a failed save, it takes 1d6 psychic damage and it must immediately use its reaction, if available, to move as far as its speed allows away from you."
                                        },
                                        "sleep spell": {
                                            "name": "Sleep",
                                            "school": "Enchantment",
                                            "casting time": "1 Action",
                                            "range": "90 feet",
                                            "duration": "1 minute",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "This spell sends creatures into a magical slumber. Roll 5d8; the total is how many hit points of creatures this spell can affect. Creatures within 20 feet of a point you choose within range are affected in ascending order of their current hit points."
                                        },
                                        "snare": {
                                            "name": "Snare",
                                            "school": "Abjuration",
                                            "casting time": "1 Minute",
                                            "range": "Touch",
                                            "duration": "Until dispelled or triggered",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You create a magic trap that triggers when a creature moves into the area or disturbs the area in any way. The trap is a circle centered on a point of your choice within range and has a diameter of 5 feet."
                                        },
                                        "speak with animals": {
                                            "name": "Speak with Animals",
                                            "school": "Divination",
                                            "casting time": "1 Action/Ritual",
                                            "range": "Self",
                                            "duration": "10 minutes",
                                            "components": "Verbal, Somatic",
                                            "description": "You gain the ability to comprehend and verbally communicate with beasts for the duration."
                                        },
                                        "sudden awakening": {
                                            "name": "Sudden Awakening (UA)",
                                            "school": "Enchantment",
                                            "casting time": "1 Bonus Action",
                                            "range": "10 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal",
                                            "description": "You jolt a creature, whether it's sleeping or unconscious, into wakefulness. The target gains one level of exhaustion."
                                        },
                                        "tashas caustic brew": {
                                            "name": "Tasha's Caustic Brew",
                                            "school": "Evocation",
                                            "casting time": "1 Action",
                                            "range": "Self (30-foot line)",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "You throw a bubble of acid. Choose one creature within range, or choose two creatures within range that are within 5 feet of each other. A target must succeed on a Dexterity saving throw or take 2d4 acid damage."
                                        },
                                        "tashas hideous laughter": {
                                            "name": "Tasha's Hideous Laughter",
                                            "school": "Enchantment",
                                            "casting time": "1 Action",
                                            "range": "30 feet",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "A creature of your choice that you can see within range perceives everything as hilariously funny and falls into fits of laughter if this spell affects it. The target must succeed on a Wisdom saving throw or fall prone, becoming incapacitated and unable to stand up for the duration."
                                        },
                                        "tensers floating disk": {
                                            "name": "Tenser's Floating Disk",
                                            "school": "Conjuration",
                                            "casting time": "1 Action/Ritual",
                                            "range": "30 feet",
                                            "duration": "1 hour",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "This spell creates a circular, horizontal plane of force, 3 feet in diameter and 1 inch thick, that floats 3 feet above the ground in an unoccupied space of your choice that you can see within range."
                                        },
                                        "thunderous smite": {
                                            "name": "Thunderous Smite",
                                            "school": "Evocation",
                                            "casting time": "1 Bonus Action",
                                            "range": "Self",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal",
                                            "description": "The first time you hit a creature with a melee weapon attack during the spell's duration, your weapon rings with thunder that is audible within 300 feet of you, and the attack deals an extra 2d6 thunder damage to the target. Additionally, if the target is a creature, it must succeed on a Strength saving throw or be pushed 10 feet away from you and knocked prone."
                                        },
                                        "thunderwave": {
                                            "name": "Thunderwave",
                                            "school": "Evocation",
                                            "casting time": "1 Action",
                                            "range": "Self (15-foot cube)",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic",
                                            "description": "A wave of thunderous force sweeps out from you. Each creature in a 15-foot cube originating from you must make a Constitution saving throw. On a failed save, a creature takes 2d8 thunder damage and is pushed 10 feet away from you. On a successful save, the creature takes half as much damage and isn't pushed."
                                        },
                                        "unearthly chorus": {
                                            "name": "Unearthly Chorus (UA)",
                                            "school": "Illusion",
                                            "casting time": "1 Action",
                                            "range": "Self (30-foot radius)",
                                            "duration": "Concentration, up to 10 minutes",
                                            "components": "Verbal",
                                            "description": "You create an unearthly chorus that can be heard from up to 30 feet away from you. Each creature within range must succeed on a Wisdom saving throw or be charmed by you for the duration."
                                        },
                                        "unseen servant": {
                                            "name": "Unseen Servant",
                                            "school": "Conjuration",
                                            "casting time": "1 Action/Ritual",
                                            "range": "60 feet",
                                            "duration": "1 hour",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "This spell creates an invisible, mindless, shapeless force that performs simple tasks at your command until the spell ends."
                                        },
                                        "wild cunning": {
                                            "name": "Wild Cunning (UA)",
                                            "school": "Transmutation",
                                            "casting time": "1 Action/Ritual",
                                            "range": "120 feet",
                                            "duration": "Instantaneous",
                                            "components": "Verbal, Somatic",
                                            "description": "You attune your senses to determine what lies behind the next door, hatch, or portcullis you reach."
                                        },
                                        "witch bolt": {
                                            "name": "Witch Bolt",
                                            "school": "Evocation",
                                            "casting time": "1 Action",
                                            "range": "30 feet",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal, Somatic, Material",
                                            "description": "A beam of crackling blue energy lances out toward a creature within range, forming a sustained arc of lightning between you and the target."
                                        },
                                        "wrathful smite": {
                                            "name": "Wrathful Smite",
                                            "school": "Evocation",
                                            "casting time": "1 Bonus Action",
                                            "range": "Self",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal",
                                            "description": "The first time you hit with a melee weapon attack during this spell's duration, your attack deals an extra 1d6 psychic damage. Additionally, if the target is a creature, it must make a Wisdom saving throw or be frightened of you until the spell ends."
                                        },
                                        "zephyr strike": {
                                            "name": "Zephyr Strike",
                                            "school": "Transmutation",
                                            "casting time": "1 Bonus Action",
                                            "range": "Self",
                                            "duration": "Concentration, up to 1 minute",
                                            "components": "Verbal",
                                            "description": "You move like the wind. Until the spell ends, your movement doesn't provoke opportunity attacks."
                                        },
                #2nd level spells
                
                  "aganazzars scorcher": {
                    "name": "Aganazzar's Scorcher",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "30 Feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "aid": {
                    "name": "Aid",
                    "school": "Abjuration",
                    "casting time": "1 Action",
                    "range": "30 Feet",
                    "duration": "8 hours",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "air bubble": {
                    "name": "Air Bubble",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "60 Feet",
                    "duration": "24 hours",
                    "components":  "Somatic" 
                  },
                  "alter self": {
                    "name": "Alter Self",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic" 
                  },
                  "animal messenger": {
                    "name": "Animal Messenger",
                    "school": "Enchantment",
                    "casting time": "1 Action R",
                    "range": "30 Feet",
                    "duration": "24 hours",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "arcane hacking": {
                    "name": "Arcane Hacking (UA)",
                    "school": "Transmutation T",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "arcane lock": {
                    "name": "Arcane Lock",
                    "school": "Abjuration",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "Until dispelled",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "augury": {
                    "name": "Augury",
                    "school": "Divination",
                    "casting time": "1 Minute R",
                    "range": "Self",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "barkskin": {
                    "name": "Barkskin",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "beast sense": {
                    "name": "Beast Sense",
                    "school": "Divination",
                    "casting time": "1 Action R",
                    "range": "Touch",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Somatic" 
                  },
                  "blindness deafness": {
                    "name": "Blindness/Deafness",
                    "school": "Necromancy",
                    "casting time": "1 Action",
                    "range": "30 Feet",
                    "duration": "1 minute",
                    "components":  "Verbal" 
                  },
                  "blur": {
                    "name": "Blur",
                    "school": "Illusion",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal" 
                  },
                  "borrowed knowledge": {
                    "name": "Borrowed Knowledge",
                    "school": "Divination",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "branding smite": {
                    "name": "Branding Smite",
                    "school": "Evocation",
                    "casting time": "1 Bonus Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal" 
                  },
                  "calm emotions": {
                    "name": "Calm Emotions",
                    "school": "Enchantment",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic" 
                  },
                  "cloud of daggers": {
                    "name": "Cloud of Daggers",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "continual flame": {
                    "name": "Continual Flame",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "Until dispelled",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "cordon of arrows": {
                    "name": "Cordon of Arrows",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "5 feet",
                    "duration": "8 hours",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "crown of madness": {
                    "name": "Crown of Madness",
                    "school": "Enchantment",
                    "casting time": "1 Action",
                    "range": "120 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic" 
                  },
                  "darkness": {
                    "name": "Darkness",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 10 minutes",
                    "components":  "Verbal, Material" 
                  },
                  "darkvision": {
                    "name": "Darkvision",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "8 hours",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "detect thoughts": {
                    "name": "Detect Thoughts",
                    "school": "Divination",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "digital phantom": {
                    "name": "Digital Phantom (UA)",
                    "school": "Abjuration T",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "dragons breath": {
                    "name": "Dragon's Breath",
                    "school": "Transmutation",
                    "casting time": "1 Bonus Action",
                    "range": "Touch",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "dust devil": {
                    "name": "Dust Devil",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "earthbind": {
                    "name": "Earthbind",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "300 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal" 
                  },
                  "enhance ability": {
                    "name": "Enhance Ability",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "enlarge reduce": {
                    "name": "Enlarge/Reduce",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "30 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "enthrall": {
                    "name": "Enthrall",
                    "school": "Enchantment",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "1 minute",
                    "components":  "Verbal, Somatic" 
                  },
                  "find steed": {
                    "name": "Find Steed",
                    "school": "Conjuration",
                    "casting time": "10 Minutes",
                    "range": "30 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic" 
                  },
                  "find traps": {
                    "name": "Find Traps",
                    "school": "Divination",
                    "casting time": "1 Action",
                    "range": "120 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic" 
                  },
                  "find vehicle": {
                    "name": "Find Vehicle (UA)",
                    "school": "Conjuration T",
                    "casting time": "10 Minutes",
                    "range": "30 feet",
                    "duration": "8 hours",
                    "components":  "Verbal, Somatic" 
                  },
                  "flame blade": {
                    "name": "Flame Blade",
                    "school": "Evocation",
                    "casting time": "1 Bonus Action",
                    "range": "Self",
                    "duration": "Concentration, up to 10 minutes",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "flaming sphere": {
                    "name": "Flaming Sphere",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "flock of familiars": {
                    "name": "Flock of Familiars",
                    "school": "Conjuration",
                    "casting time": "1 Minute",
                    "range": "Touch",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic" 
                  },
                  "fortunes favor": {
                    "name": "Fortune's Favor",
                    "school": "Divination D",
                    "casting time": "1 Minute",
                    "range": "60 feet",
                    "duration": "1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "gentle repose": {
                    "name": "Gentle Repose",
                    "school": "Necromancy",
                    "casting time": "1 Action R",
                    "range": "Touch",
                    "duration": "10 days",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "gift of gab": {
                    "name": "Gift of Gab",
                    "school": "Enchantment",
                    "casting time": "Reaction",
                    "range": "Self",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "gust of wind": {
                    "name": "Gust of Wind",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "Self (60-foot line)",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "healing spirit": {
                    "name": "Healing Spirit",
                    "school": "Conjuration",
                    "casting time": "1 Bonus Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic" 
                  },
                  "heat metal": {
                    "name": "Heat Metal",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "hold person": {
                    "name": "Hold Person",
                    "school": "Enchantment",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "icingdeaths frost": {
                    "name": "Icingdeath's Frost (UA)",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "Self (15-foot cone)",
                    "duration": "Instantaneous",
                    "components":  "Somatic, Material" 
                  },
                  "immovable object": {
                    "name": "Immovable Object",
                    "school": "Transmutation DG",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "invisibility": {
                    "name": "Invisibility",
                    "school": "Illusion",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "jims glowing coin": {
                    "name": "Jim's Glowing Coin",
                    "school": "Enchantment",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "1 minute",
                    "components":  "Somatic, Material" 
                  },
                  "kinetic jaunt": {
                    "name": "Kinetic Jaunt",
                    "school": "Transmutation",
                    "casting time": "1 Bonus Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Somatic" 
                  },
                  "knock": {
                    "name": "Knock",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal" 
                  },
                  "lesser restoration": {
                    "name": "Lesser Restoration",
                    "school": "Abjuration",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic" 
                  },
                  "levitate": {
                    "name": "Levitate",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 10 minutes",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "locate animals or plants": {
                    "name": "Locate Animals or Plants",
                    "school": "Divination",
                    "casting time": "1 Action R",
                    "range": "Self",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "locate object": {
                    "name": "Locate Object",
                    "school": "Divination",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "Concentration, up to 10 minutes",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "magic mouth": {
                    "name": "Magic Mouth",
                    "school": "Illusion",
                    "casting time": "1 Minute R",
                    "range": "30 feet",
                    "duration": "Until dispelled",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "magic weapon": {
                    "name": "Magic Weapon",
                    "school": "Transmutation",
                    "casting time": "1 Bonus Action",
                    "range": "Touch",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic" 
                  },
                  "maximillians earthen grasp": {
                    "name": "Maximillian's Earthen Grasp",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "30 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "melfs acid arrow": {
                    "name": "Melf's Acid Arrow",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "90 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "mental barrier": {
                    "name": "Mental Barrier (UA)",
                    "school": "Abjuration",
                    "casting time": "1 Reaction",
                    "range": "Self",
                    "duration": "1 round",
                    "components":  "Verbal" 
                  },
                  "mind spike": {
                    "name": "Mind Spike",
                    "school": "Divination",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Somatic" 
                  },
                  "mind thrust": {
                    "name": "Mind Thrust (UA)",
                    "school": "Enchantment",
                    "casting time": "1 Bonus Action",
                    "range": "60 feet",
                    "duration": "1 round",
                    "components":  "Verbal, Somatic" 
                  },
                  "mirror image": {
                    "name": "Mirror Image",
                    "school": "Illusion",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "1 minute",
                    "components":  "Verbal, Somatic" 
                  },
                  "misty step": {
                    "name": "Misty Step",
                    "school": "Conjuration",
                    "casting time": "1 Bonus Action",
                    "range": "Self",
                    "duration": "Instantaneous",
                    "components":  "Verbal" 
                  },
                  "moonbeam": {
                    "name": "Moonbeam",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "120 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "nondetection": {
                    "name": "Nondetection",
                    "school": "Abjuration",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "8 hours",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "oceans embrace": {
                    "name": "Ocean's Embrace (UA)",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "pass without trace": {
                    "name": "Pass without Trace",
                    "school": "Abjuration",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "phantom steed": {
                    "name": "Phantom Steed",
                    "school": "Illusion",
                    "casting time": "1 Minute",
                    "range": "30 feet",
                    "duration": "1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "protection from energy": {
                    "name": "Protection from Energy",
                    "school": "Abjuration",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "pyrotechnics": {
                    "name": "Pyrotechnics",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic" 
                  },
                  "ray of enfeeblement": {
                    "name": "Ray of Enfeeblement",
                    "school": "Necromancy",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic" 
                  },
                  "ray of frost": {
                    "name": "Ray of Frost",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic" 
                  },
                  "reincarnate": {
                    "name": "Reincarnate",
                    "school": "Transmutation",
                    "casting time": "1 Hour",
                    "range": "Touch",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "rope trick": {
                    "name": "Rope Trick",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "schooled caster": {
                    "name": "Schooled Caster (UA)",
                    "school": "Transmutation T",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "Concentration, up to 10 minutes",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "see invisibility": {
                    "name": "See Invisibility",
                    "school": "Divination",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "shadow blade": {
                    "name": "Shadow Blade",
                    "school": "Illusion",
                    "casting time": "1 Bonus Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "shield": {
                    "name": "Shield",
                    "school": "Abjuration",
                    "casting time": "1 Reaction",
                    "range": "Self",
                    "duration": "1 round",
                    "components":  "Verbal, Somatic" 
                  },
                  "shillelagh": {
                    "name": "Shillelagh",
                    "school": "Transmutation",
                    "casting time": "1 Bonus Action",
                    "range": "Touch",
                    "duration": "1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "sickening radiance": {
                    "name": "Sickening Radiance",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "120 feet",
                    "duration": "Concentration, up to 10 minutes",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "silence": {
                    "name": "Silence",
                    "school": "Illusion",
                    "casting time": "1 Action",
                    "range": "120 feet",
                    "duration": "Concentration, up to 10 minutes",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "sleep": {
                    "name": "Sleep",
                    "school": "Enchantment",
                    "casting time": "1 Action",
                    "range": "90 feet",
                    "duration": "1 minute",
                    "components":  "Verbal, Material" 
                  },
                  "slow": {
                    "name": "Slow",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "120 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "snare": {
                    "name": "Snare",
                    "school": "Abjuration",
                    "casting time": "1 Minute",
                    "range": "Touch",
                    "duration": "8 hours",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "snillocs snowball swarm": {
                    "name": "Snilloc's Snowball Swarm",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "90 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "spider climb": {
                    "name": "Spider Climb",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "spirit shroud": {
                    "name": "Spirit Shroud",
                    "school": "Necromancy",
                    "casting time": "1 Bonus Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "stinking cloud": {
                    "name": "Stinking Cloud",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "90 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "suggestion": {
                    "name": "Suggestion",
                    "school": "Enchantment",
                    "casting time": "1 Action",
                    "range": "30 feet",
                    "duration": "Concentration, up to 8 hours",
                    "components":  "Verbal" 
                  },
                  "summon beast": {
                    "name": "Summon Beast (UA)",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "90 feet",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "summon construct": {
                    "name": "Summon Construct (UA)",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "90 feet",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "summon undead": {
                    "name": "Summon Undead (UA)",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "90 feet",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "summoning sickness": {
                    "name": "Summoning Sickness (UA)",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "90 feet",
                    "duration": "1 round",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "sunsphere": {
                    "name": "Sunsphere (UA)",
                    "school": "Evocation",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "tashas hideous laughter": {
                    "name": "Tasha's Hideous Laughter",
                    "school": "Enchantment",
                    "casting time": "1 Action",
                    "range": "30 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "tensers floating disk": {
                    "name": "Tenser's Floating Disk",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "30 feet",
                    "duration": "1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "thunder step": {
                    "name": "Thunder Step",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "90 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal" 
                  },
                  "tidal wave": {
                    "name": "Tidal Wave",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "120 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "tiny servant": {
                    "name": "Tiny Servant",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "Touch",
                    "duration": "8 hours",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "toll the dead": {
                    "name": "Toll the Dead",
                    "school": "Necromancy",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal, Somatic" 
                  },
                  "transmute rock": {
                    "name": "Transmute Rock",
                    "school": "Transmutation",
                    "casting time": "1 Action",
                    "range": "120 feet",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "vampiric touch": {
                    "name": "Vampiric Touch",
                    "school": "Necromancy",
                    "casting time": "1 Action",
                    "range": "Self",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic" 
                  },
                  "web": {
                    "name": "Web",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 hour",
                    "components":  "Verbal, Somatic, Material" 
                  },
                  "wither and bloom": {
                    "name": "Wither and Bloom (UA)",
                    "school": "Necromancy",
                    "casting time": "1 Action",
                    "range": "60 feet",
                    "duration": "Concentration, up to 1 minute",
                    "components":  "Verbal, Somatic" 
                  },
                  "word of recall": {
                    "name": "Word of Recall",
                    "school": "Conjuration",
                    "casting time": "1 Action",
                    "range": "5 feet",
                    "duration": "Instantaneous",
                    "components":  "Verbal" 
                  }
                }    

                

                





#3rd lvel spells 

animate_dead = ["", "Animate Dead", "Necromancy", "1 Minute", "10 feet", "Instantaneous", "V", "S", "M"]

antagonize = ["", "Antagonize", "Enchantment", "1 Action", "30 feet", "Instantaneous", "V", "S", "M"]

antagonize_ua = ["", "Antagonize (UA)", "Enchantment", "1 Action", "30 feet", "Instantaneous", "V", "S", "M"]

ashardalons_stride = ["", "Ashardalon's Stride", "Transmutation", "1 Bonus Action", "Self", "Concentration, up to 1 minute", "V", "S"]

aura_of_vitality = ["", "Aura of Vitality", "Evocation", "1 Action", "Self (30-foot radius)", "Concentration, up to 1 minute", "V"]

beacon_of_hope = ["", "Beacon of Hope", "Abjuration", "1 Action", "30 feet", "Concentration, up to 1 minute", "V", "S"]

bestow_curse = ["", "Bestow Curse", "Necromancy", "1 Action", "Touch", "Concentration, up to 1 minute", "V", "S"]

blinding_smite = ["", "Blinding Smite", "Evocation", "1 Bonus Action", "Self", "Concentration, up to 1 minute", "V"]

blink = ["", "Blink", "Transmutation", "1 Action", "Self", "1 minute", "V", "S"]

call_lightning = ["", "Call Lightning", "Conjuration", "1 Action", "120 feet", "Concentration, up to 10 minutes", "V", "S"]

catnap = ["", "Catnap", "Enchantment", "1 Action", "30 feet", "10 minutes", "S", "M"]

clairvoyance = ["", "Clairvoyance", "Divination", "10 Minutes", "1 mile", "Concentration, up to 10 minutes", "V", "S", "M"]

conjure_animals = ["", "Conjure Animals", "Conjuration", "1 Action", "60 feet", "Concentration, up to 1 hour", "V", "S"]

conjure_barrage = ["", "Conjure Barrage", "Conjuration", "1 Action", "Self (60-foot cone)", "Instantaneous", "V", "S", "M"]

conjure_lesser_demon_ua = ["", "Conjure Lesser Demon (UA)", "Conjuration", "1 Action", "60 feet", "Concentration, up to 1 hour", "V", "S", "M"]

counterspell = ["", "Counterspell", "Abjuration", "1 Reaction", "60 feet", "Instantaneous", "S"]

create_food_and_water = ["", "Create Food and Water", "Conjuration", "1 Action", "30 feet", "Instantaneous", "V", "S"]

crusaders_mantle = ["", "Crusader's Mantle", "Evocation", "1 Action", "Self", "Concentration, up to 1 minute", "V"]

daylight = ["", "Daylight", "Evocation", "1 Action", "60 feet", "1 hour", "V", "S"]

dispel_magic = ["", "Dispel Magic", "Abjuration", "1 Action", "120 feet", "Instantaneous", "V", "S"]

elemental_weapon = ["", "Elemental Weapon", "Transmutation", "1 Action", "Touch", "Concentration, up to 1 hour", "V", "S"]

enemies_abound = ["", "Enemies Abound", "Enchantment", "1 Action", "120 feet", "Concentration, up to 1 minute", "V", "S"]

erupting_earth = ["", "Erupting Earth", "Transmutation", "1 Action", "120 feet", "Instantaneous", "V", "S", "M"]

fast_friends = ["", "Fast Friends", "Enchantment", "1 Action", "30 feet", "Concentration, up to 1 hour", "V"]

fear = ["", "Fear", "Illusion", "1 Action", "Self (30-foot cone)", "Concentration, up to 1 minute", "V", "S", "M"]

feign_death = ["", "Feign Death", "Necromancy", "1 Action R", "Touch", "1 hour", "V", "S", "M"]

fireball = ["", "Fireball", "Evocation", "1 Action", "150 feet", "Instantaneous", "V", "S", "M"]

flame_arrows = ["", "Flame Arrows", "Transmutation", "1 Action", "Touch", "Concentration, up to 1 hour", "V", "S"]

flame_stride_ua = ["", "Flame Stride (UA)", "Transmutation", "1 Bonus Action", "Self", "Concentration, up to 1 minute", "V", "S"]

fly = ["", "Fly", "Transmutation", "1 Action", "Touch", "Concentration, up to 10 minutes", "V", "S", "M"]

freedom_of_the_waves_hb = ["", "Freedom of the Waves (HB)", "Conjuration HB", "1 action", "120 feet", "Instantaneous", "V", "S", "M"]

galders_tower = ["", "Galder's Tower", "Conjuration", "10 Minutes", "30 feet", "24 hours", "V", "S", "M"]

gaseous_form = ["", "Gaseous Form", "Transmutation", "1 Action", "Touch", "Concentration, up to 1 hour", "V", "S", "M"]

glyph_of_warding = ["", "Glyph of Warding", "Abjuration", "1 Hour", "Touch", "Until dispelled or triggered", "V", "S", "M"]

haste = ["", "Haste", "Transmutation", "1 Action", "30 feet", "Concentration, up to 1 minute", "V", "S", "M"]

haywire = ["", "Haywire", "Enchantment", "1 Action", "90 feet", "Concentration, up to 1 minute", "V", "S"]

house_of_cards = ["", "House of Cards", "Conjuration", "1 Minute", "Touch", "24 hours", "V", "S", "M"]

hunger_of_hadar = ["", "Hunger Of Hadar", "Conjuration", "1 Action", "150 feet", "Concentration, up to 1 minute", "V", "S", "M"]

hypnotic_pattern = ["", "Hypnotic Pattern", "Illusion", "1 Action", "120 feet", "Concentration, up to 1 minute", "S", "M"]

incite_greed = ["", "Incite Greed", "Enchantment", "1 action", "30 feet", "Concentration, up to 1 minute", "V", "S", "M"]

intellect_fortress = ["", "Intellect Fortress", "Abjuration", "1 Action", "30 feet", "Concentration, up to 1 hour", "V"]

invisibility_to_cameras = ["", "Invisibility To Cameras", "Illusion", "1 Action", "10 feet", "Concentration, up to 1 minute", "V", "S", "M"]

leomunds_tiny_hut = ["", "Leomund's Tiny Hut", "Evocation", "1 Minute", "Self (10-foot radius hemisphere)", "8 hours", "V", "S", "M"]

life_transference = ["", "Life Transference", "Necromancy", "1 Action", "30 feet", "Instantaneous", "V", "S"]

lightning_arrow = ["", "Lightning Arrow", "Transmutation", "1 Bonus Action", "Self", "Concentration, up to 1 minute", "V", "S"]

lightning_bolt = ["", "Lightning Bolt", "Evocation", "1 Action", "Self (100-foot line)", "Instantaneous", "V", "S", "M"]

magic_circle = ["", "Magic Circle", "Abjuration", "1 Minute", "10 feet", "1 hour", "V", "S", "M"]

major_image = ["", "Major Image", "Illusion", "1 Action", "120 feet", "Concentration, up to 10 minutes", "V", "S", "M"]

mass_healing_word = ["", "Mass Healing Word", "Evocation", "1 Bonus Action", "60 feet", "Instantaneous", "V"]


meld_into_stone = ["", "Meld into Stone", "Transmutation", "1 Action R", "Touch", "8 hours", "V", "S"]

melfs_minute_meteors = ["", "Melf's Minute Meteors", "Evocation", "1 Action", "Self (120 feet)", "Concentration, up to 10 minutes", "V", "S", "M"]

motivational_speech = ["", "Motivational Speech", "Enchantment", "1 hour", "60 feet", "1 hour", "V"]

nondetection = ["", "Nondetection", "Abjuration", "1 Action", "Touch", "8 hours", "V", "S", "M"]

phantom_steed = ["", "Phantom Steed", "Illusion", "1 Minute R", "30 feet", "1 hour", "V", "S"]

plant_growth = ["", "Plant Growth", "Transmutation", "1 Action or 8 Hours", "150 feet", "Instantaneous", "V", "S"]

protection_from_ballistics = ["", "Protection from Ballistics", "Abjuration", "1 Action", "Touch", "Concentration, up to 10 minutes", "V", "S", "M"]

protection_from_energy = ["", "Protection from Energy", "Abjuration", "1 Action", "Touch", "Concentration, up to 1 hour", "V", "S"]

psionic_blast = ["", "Psionic Blast", "Evocation", "1 Action", "Self (30-foot cone)", "Instantaneous", "V"]

pulse_wave = ["", "Pulse Wave", "Evocation", "1 Action", "Self (30-foot cone)", "Instantaneous", "V", "S"]

remove_curse = ["", "Remove Curse", "Abjuration", "1 Action", "Touch", "Instantaneous", "V", "S"]

revivify = ["", "Revivify", "Necromancy", "1 Action", "Touch", "Instantaneous", "V", "S", "M"]

sending = ["", "Sending", "Evocation", "1 Action", "Unlimited", "1 round", "V", "S", "M"]

sleet_storm = ["", "Sleet Storm", "Conjuration", "1 Action", "120 feet", "Concentration, up to 1 minute", "V", "S", "M"]

slow = ["", "Slow", "Transmutation", "1 Action", "120 feet", "Concentration, up to 1 minute", "V", "S", "M"]

speak_with_dead = ["", "Speak with Dead", "Necromancy", "1 Action", "10 feet", "10 minutes", "V", "S", "M"]

speak_with_plants = ["", "Speak with Plants", "Transmutation", "1 Action", "Self (30-foot radius)", "10 minutes", "V", "S"]

spirit_guardians = ["", "Spirit Guardians", "Conjuration", "1 Action", "Self (15-foot radius)", "Concentration, up to 10 minutes", "V", "S", "M"]

spirit_shroud = ["", "Spirit Shroud", "Necromancy", "1 Bonus Action", "Self", "Concentration, up to 1 minute", "V", "S"]

stinking_cloud = ["", "Stinking Cloud", "Conjuration", "1 Action", "90 feet", "Concentration, up to 1 minute", "V", "S", "M"]

summon_fey = ["", "Summon Fey", "Conjuration", "1 Action", "90 feet", "Concentration, up to 1 hour", "V", "S", "M"]

summon_lesser_demons = ["", "Summon Lesser Demons", "Conjuration", "1 Action", "60 Feet", "Concentration, up to 1 hour", "V", "S", "M"]

summon_shadowspawn = ["", "Summon Shadowspawn", "Conjuration", "1 Action", "90 feet", "Concentration, up to 1 hour", "V", "S", "M"]

summon_undead = ["", "Summon Undead", "Necromancy", "1 Action", "90 feet", "Concentration, up to 1 hour", "V", "S", "M"]

summon_warrior_spirit = ["", "Summon Warrior Spirit", "Conjuration", "1 Action", "90 feet", "Concentration, up to 1 hour", "V", "S", "M"]

thunder_step = ["", "Thunder Step", "Conjuration", "1 Action", "90 feet", "Instantaneous", "V"]

tidal_wave = ["", "Tidal Wave", "Conjuration", "1 Action", "120 feet", "Instantaneous", "V", "S", "M"]

tiny_servant = ["", "Tiny Servant", "Transmutation", "1 Minute", "Touch", "8 hours", "V", "S"]

tongues = ["", "Tongues", "Divination", "1 Action", "Touch", "1 hour", "V", "M"]

vampiric_touch = ["", "Vampiric Touch", "Necromancy", "1 Action", "Self", "Concentration, up to 1 minute", "V", "S"]

wall_of_sand = ["", "Wall of Sand", "Evocation", "1 Action", "90 feet", "Concentration, up to 10 minutes", "V", "S", "M"]

wall_of_water = ["", "Wall of Water", "Evocation", "1 Action", "60 feet", "Concentration, up to 10 minutes", "V", "S", "M"]

water_breathing = ["", "Water Breathing", "Transmutation", "1 Action R", "30 feet", "24 hours", "V", "S", "M"]

water_walk = ["", "Water Walk", "Transmutation", "1 Action R", "30 feet", "1 hour", "V", "S", "M"]

wind_wall = ["", "Wind Wall", "Evocation", "1 Action", "120 feet", "Concentration, up to 1 minute", "V", "S", "M"]


