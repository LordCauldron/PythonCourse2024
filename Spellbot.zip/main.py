# bot.py

import discord
import os
from SpellList import *
from helpers import reply_to_all, upside_down, USERNAME, TOKEN
from random import randint, choice

# Enter these 2 values yourself in helpers.py. Your username can be found in Discord this is your unique user ID (long number in the form 123457890123456789), your token in the Discord Developer portal:
# https://discord.com/developers/applications
_TOKEN = "MTIzMjM2MTE4NDg1MDg3MDMzMg.GzxM2i.GOScoAbwF-6Yd0XCT0v0N58UyRalf4NfZ1iXZ4"
_USERNAME = "133634394555416576"

intents = discord.Intents.default()
intents.message_content = True

client = discord.Client(intents=intents)


classes = [
    "Bard",
    "Cleric",
    "Druid",
    "Sorcerer",
    "Wizard",
    "Artificer",
    "Paladin",
    "Ranger",
    "Warlock",
]

@reply_to_all(client)
def send_message(message):
  if message.author.id == _USERNAME:
    return   
    
  for word_index in range(len(message.content.split())):
    for end_index in range(word_index, len(message.content.split())):
        current_phrase = ' '.join(message.content.split()[word_index:end_index + 1]).lower()
        if current_phrase in spell_details:
            spell_info = spell_details[current_phrase]
            return (
                f"Spell: {spell_info['name']}\n"
                f"School: {spell_info['school']}\n"
                f"Casting Time: {spell_info['casting time']}\n"
                f"Range: {spell_info['range']}\n"
                f"Duration: {spell_info['duration']}\n"
                f"Components: {spell_info['components']}\n"
                f"Description: {spell_info['description']}"
            )
        
          
  
  if message.content.startswith("!Classes"):
    return f" :violin: **Bard** :violin: :church: **Cleric** :church: :evergreen_tree: **Druid** :evergreen_tree: :magic_wand: **Sorcerer** :magic_wand: :book: **Wizard** :book: :gear: \n **Artificer** :gear: :crossed_swords: **Paladin** :crossed_swords: :bow_and_arrow: **Ranger** :bow_and_arrow: :imp: **Warlock** :imp: "
  
  if message.content.startswith("!Spellbot"):
    return f" I am a spell bot designed to help you learn your spells. Type !Classes to see what classes you can find in Dungeons and Dragons 5th Edition. or ask for a spell levle of your desired class to learn what spells you class can cast."
 


  
  if "bard" in message.content.lower():
    if "cantrips" in message.content.lower():
      return "**Bard Cantrips** \n" + "\n".join(bard_cantrips)
    elif "1st" in message.content.lower() or "first" in message.content.lower():
      return "**1st level spells** \n" + "\n".join(bard_first_level_spells)
    elif "2nd" in message.content.lower() or "second" in message.content.lower():
      return "**2nd level spells** \n" + "\n".join(bard_second_level_spells)
    elif "3rd" in message.content.lower():
      return "**3rd level spells** \n" + "\n".join(bard_third_level_spells)
    else:
      return "Bards have Cantrips to 9th level spells available to them."

  if "cleric" in message.content.lower():
    if "cantrips" in message.content.lower():
        return "**Cleric Cantrips** \n" + "\n".join(cleric_cantrips)
    elif "1st" in message.content.lower() or "first" in message.content.lower():
        return "**1st level spells** \n" + "\n".join(cleric_first_level_spells)
    elif "2nd" in message.content.lower() or "second" in message.content.lower():
        return "**2nd level spells** \n" + "\n".join(cleric_second_level_spells)
    elif "3rd" in message.content.lower():
        return "**3rd level spells** \n" + "\n".join(cleric_third_level_spells)
    else:
        return "Clerics have Cantrips to 9th level spells available to them."

  if "druid" in message.content.lower():
    if "cantrips" in message.content.lower():
        return "**druid Cantrips** \n" + "\n".join(druid_cantrips)
    elif "1st" in message.content.lower() or "first" in message.content.lower():
        return "**1st level spells** \n" + "\n".join(druid_first_level_spells)
    elif "2nd" in message.content.lower() or "second" in message.content.lower():
        return "**2nd level spells** \n" + "\n".join(druid_second_level_spells)
    elif "3rd" in message.content.lower():
        return "**3rd level spells** \n" + "\n".join(druid_third_level_spells)
    else:
        return "Druids have Cantrips to 9th level spells available to them."

  if "sorcerer" in message.content.lower():
    if "cantrips" in message.content.lower():
        return "**sorcerer Cantrips** \n" + "\n".join(sorcerer_cantrips)
    elif "1st" in message.content.lower() or "first" in message.content.lower():
        return "**1st level spells** \n" + "\n".join(sorcerer_first_level_spells)
    elif "2nd" in message.content.lower() or "second" in message.content.lower():
        return "**2nd level spells** \n" + "\n".join(sorcerer_second_level_spells)
    elif "3rd" in message.content.lower():
        return "**3rd level spells** \n" + "\n".join(sorcerer_third_level_spells)
    else:
        return "Sorcerers have Cantrips to 9th level spells available to them."

  if "wizard" in message.content.lower():
    if "cantrips" in message.content.lower():
        return "**wizard Cantrips** \n" + "\n".join(wizard_cantrips)
    elif "1st" in message.content.lower() or "first" in message.content.lower():
        return "**1st level spells** \n" + "\n".join(wizard_first_level_spells)
    elif "2nd" in message.content.lower() or "second" in message.content.lower():
        return "**2nd level spells** \n" + "\n".join(wizard_second_level_spells)
    elif "3rd" in message.content.lower():
        return "**3rd level spells** \n" + "\n".join(wizard_third_level_spells)
    else:
        return "Wizard have Cantrips to 9th level spells available to them."
      
#  else:
 #   return "I am a spell bot designed to help you learn your spells. Type !Classes to see what classes you can find in Dungeons and Dragons 5th Edition. or ask for a spell levle of your desired class to learn what spells you class can cast."

#artificer
#Paladin
#Ranger
#Warlock

 

  
  
  
  

  
 

try:
  print("Lets go")
  client.run(TOKEN)
except Exception as e:
  print(e)
  os.system("kill 1")
