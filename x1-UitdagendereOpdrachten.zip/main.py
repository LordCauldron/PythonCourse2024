# Extra uitdagingen:

# Een palindroom is een woord dat van voor naar achter en andersom exact hetzelfde is, zoals 'legovogel'. 
# > Vraag een gebruiker met input om een woord, en controleer of het een palindroom is. Wat voorbeelden: racecar, otto, maandnaam, legermeetsysteemregel, kook.
# > Let op: Python ziet kleine letters en hoofdletters als verschillende letters, maar voor een palindroom maakt dat niet uit.
# > Extra: Het kan eventueel ook met zinnen: 'Ai, de media', 'Er is daar nog onraad, Sire', let er dan op dat spaties niet meetellen.



# Bubblesort is een simpel sorteeralgoritme waarbij je steeds door een lijst loopt, naar twee elementen tegelijk kijkt en deze omwisselt als ze niet op de juiste volgorde staan:

# [0,1,5,3,2,6] # Staan goed
#  ^ ^
# [0,1,5,3,2,6] # Staan goed
#    ^ ^
# [0,1,5,3,2,6] # Staan niet goed
#      ^ ^
# [0,1,3,5,2,6] # Verwisseld
#      ^ ^
# [0,1,3,5,2,6] # Staan ook niet goed
#        ^ ^
# [0,1,3,2,5,6] # Verwisseld
#        ^ ^
# [0,1,3,2,5,6] # Staan goed, einde van pass
#          ^ ^ 
# Hierna begint de loop opnieuw, totdat er na een 'pass' (een cycle) niets meer veranderd is.
# > Implementeer je eigen Bubble sort. Laat een lijst vullen d.m.v. input óf d.m.v. random getallen (hiervoor moet je even Googlen hoe je dat moet doen)




#Additional challenges:

# A palindrome is a word that is exactly the same from front to back and vice versa, such as "legovogel. 
# > Ask a user with input for a word, and check if it is a palindrome. Some examples: racecar, otto, month name, army system rule, kook.
# > Note: Python sees lowercase and uppercase letters as different letters, but for a palindrome it doesn't matter.
# > Extra: It can also possibly be done with phrases: 'Ai, the media', 'There's still trouble there, Sire', just make sure that spaces don't count.



word = input('please write a single word, and lets check if its a palindrome. ')
def word_check():
  new_word = word.lower().replace(',','').replace(' ','')
  print(new_word)
  palindrome_check = new_word[::-1]
  if new_word == palindrome_check:
    print(f'{word} is a plaindrome')
  else:
   print(f'{word} is not a plaindrome')

word_check()
  


# Bubblesort is a simple sorting algorithm where you keep going through a list, looking at two elements at a time and swapping them if they are not in the right order:

# [0,1,5,3,2,6] # Stand right
# ^ ^
# [0,1,5,3,2,6] # Stand correct
# ^ ^
# [0,1,5,3,2,6] # Do not stand good
# ^ ^
# [0,1,3,5,2,6] # Swapped out
# ^ ^
# [0,1,3,5,2,6] # Don't stand right either
# ^ ^
# [0,1,3,2,5,6] # Interchanged
# ^ ^
# [0,1,3,2,5,6] # Stand right, end of pass
# ^ ^ 
# After this, the loop starts again, until nothing has changed after a 'pass' (a cycle).
# > Implement your own Bubble sort. Fill a list either with input or with random numbers (just google how to do that).

def bubble_sort(lst):
  for iterations in range(len(lst)):
      for steps in range(len(lst) - 1 - iterations):
          if lst[steps] > lst[steps + 1]:
              lst[steps], lst[steps + 1] = lst[steps + 1], lst[steps]
              print(lst)

bracket_1 = []
bracket_2 = ']'

nr_list = [5,16,9,152,20,654,54,28,1289,145,1,124,555]

word_list = ['hi','my','name','is','hi','my','name','is','hi','my','name','is', 'slimshady']

input_list = input('Please input the items that you want in your list, separated by space: ')
primed_input_list = input_list.lower().split()  # Split the input string into a list of items

bubble_sort(primed_input_list)