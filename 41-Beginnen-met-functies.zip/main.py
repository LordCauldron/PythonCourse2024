#>>>>>>>>>>>>>>>>>>>>>>>>>English<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


# In this assignment we will practice some things with functions
# You will also convert code that you have previously written for an assignment
# into functions, so that they can be used more easily if necessary

# In assignment 2, you wrote a fizzbuzz program
# In it we could use the % operator to check if number X
# was fully divisible by number Y.
# Write a function that performs this check for you. What do you need for this?
# > What are you going to give the function?
# > What will the function return?
# > What happens within the function to turn the parameters into the return value?
# So as an outcome we would want to be able to do something like:

print('This is section 1')
def fizzbuzz(number):
  if number % 3 == 0 and number % 5 == 0:
    return('Fizz and buzz')
  elif number % 3 == 0:
    return('Fizz')
  elif number % 5 == 0:
    return('Buzz')
  else:
    return(number)

chosen_nr = float(input('input 1:number '))
chosen_nr = int(chosen_nr)
fizzbuzz(chosen_nr)
print(fizzbuzz(chosen_nr))

chosen_nr2 = input('input 2:number ')
chosen_nr2 = int(chosen_nr2)
int(chosen_nr2)
fizzbuzz(chosen_nr2)
print(fizzbuzz(chosen_nr2))

chosen_nr3 = input('input 3:number ')
chosen_nr3 = int(chosen_nr3)
int(chosen_nr3)
fizzbuzz(chosen_nr3)
print(fizzbuzz(chosen_nr3))



# print(fullyDivisble(15,3)) # So, is 15 fully divisible by 3?
# >>> True
# print(fullyDivisible(16,3))
# >>> False
print('This is section 2')
def fullyDivisble(number, div):
  return number % div == 0
print(fullyDivisble(15, 3))
print(fullyDivisble(16, 3))

# We also talked briefly about function composition, so combining
# functions to get more complicated behavior done
# >> Create a function that can run the entire fizzbuzz program for you. To do this
# use the function you wrote in the previous assignment
# Example output:

print('This is section 3')
print(fizzbuzz(12))
# >>> Fizz
print(fizzbuzz(15))
# >>> Fizzbuzz
print(fizzbuzz(20))
# >>> Buzz
print(fizzbuzz(4))
# >>> 4

print('This is section 4')

from hidden import text1


def vowel_count(vowel,):
  text1.lower()
  return(text1.count(vowel))


a = vowel_count('a')
u = vowel_count('u')
o = vowel_count('o')
e = vowel_count('e')
i = vowel_count('i')

inputted_vowel = input('input vowel--> ')
if 'a' in inputted_vowel:
  print(f' a appears {a} in the text')
elif 'u' in inputted_vowel:
  print(f' u appears {u} in the text')
elif 'o' in inputted_vowel:
  print(f' o appears {o} in the text')
elif 'e' in inputted_vowel:
  print(f' e appears {e} in the text')
elif 'i' in inputted_vowel:
  print(f' i appears {i} in the text')
else:
  print('try again')
# In assignment 3, for example, we printed out how many times each vowel occurred in a 
# given piece of text occurred. For this we used string.count(vowel) function
# We just had to manually write these out 5 times each time - and if we want to
# print this for a different piece of text you have to write them out another 5 times. We can
# we can make a function for that!

# Write a function that takes a piece of text, and then prints out for that text how many times
# each vowel occurs.
# Again, think carefully about what this function should carry and what it will return. 
# Example output:
