# > Write a function that returns whether a key is in a dictionary or not (True or False)

taart_dict = {'appeltaart': 'goed', 'slagroomtaart': 'slecht'}


def is_key_in_dict(key, my_dict):
  return key in my_dict


print(is_key_in_dict('appeltaart', taart_dict))
print(is_key_in_dict('frambozenvlaai', taart_dict))

# # # > Write a function that returns whether a given value is in a dictionary or not


def is_value_in_dict(value, my_dict):
  return value in my_dict.values()


print(is_value_in_dict('goed', taart_dict))
print(is_value_in_dict(42, taart_dict))

# # # > Write a function that takes a name and returns a formatted string of the person's name and associated number. If the person is not listed, return a string that makes this clear.

cijfers = {'Robert': 10, 'Nick': 10, 'Jan': 'Onvoldoende', 'Vera': 10}


def give_and_number(name, cijfers):
  if name in cijfers:
    return f"{name} have a number of {cijfers[name]}"
  else:
    return f"{name} is not in the list."


print(give_and_number('Vera', cijfers))
print(give_and_number('Florian', cijfers))


# # # > Write a function that calculates the average age of all cars in the dictionary.
def calculate_average_car_age(car_database):
  total_age = sum(2024 - year for year in car_database.values())
  return total_age / len(car_database)


car_database = {
    'DeLorean DMC-12': 1981,
    'Ford Mustang': 1964,
    'Ford F150': 1948,
    'Ford Ka': 1996,
    'Bugatti type 55': 1931,
    'Tesla Roadster': 2008,
    'Tesla Model 3': 2016,
    'Ford focus': 1998
}
print(calculate_average_car_age(car_database))

# # # In previous assignments we have counted all the vowels in a piece of text several times. Now we are going to do this again, but with a dictionary.
# # # > Rewrite your function from last lesson, where you could pass a piece of text and a number of letters to count them, so that it now returns a dictionary that has the letters as a key and as a value how many times this letter occurred.

#old text
#def vowel_count(vowel,):
#  text1.lower()
#  return(text1.count(vowel))

#a = vowel_count('a')
#u = vowel_count('u')
#o = vowel_count('o')
#e = vowel_count('e')
#i = vowel_count('i')

#inputted_vowel = input('input vowel--> ')
#if 'a' in inputted_vowel:
# print(f' a appears {a} in the text')
#elif 'u' in inputted_vowel:
#  print(f' u appears {u} in the text')
#elif 'o' in inputted_vowel:
#  print(f' o appears {o} in the text')
#elif 'e' in inputted_vowel:
#  print(f' e appears {e} in the text')
#elif 'i' in inputted_vowel:
#  print(f' i appears {i} in the text')
#else:
#  print('try again')


def vowel_count(text):
  # Convert text to lowercase to make counting case-insensitive
  text = text.lower()

  # Initialize an empty dictionary to store vowel counts
  vowel_counts = {'a': 0, 'e': 0, 'i': 0, 'o': 0, 'u': 0}

  # Iterate over each character in the text
  for char in text:
    # Check if the character is a vowel
    if char in 'aeiou':
      # Increment the count for the vowel in the dictionary
      vowel_counts[char] += 1

  # Return the dictionary with vowel counts
  return vowel_counts


# Example usage:
text = input("input text for vowel check. ")
vowel_counts = vowel_count(text)
print(vowel_counts)
