# CAUTION: Many of the solutions are possible solutions. If you did it differently it may as well be right.

# Take a look at your fizzbuzz from last week.
# Now we want to run fizzbuzz for all numbers from 1 to 100
# With input this would take too long ;)
# Now write this with a loop, so that this happens automatically

for number in range(1, 101):
  if number % 3 == 0 and number % 5 == 0:
      print('FizzBuzz')
  elif number % 3 == 0:
      print('Fizz')
  elif number % 5 == 0:
      print('Buzz')
  else:
      print(number)


# print all even numbers from 0 to 42

for number in range(0, 43, 2):
  print(number)


# Write a loop that prints a triangle of asterisks, such as
# *
# * *
# * * *
# etc.
# Do this up to 10 stars.

for stars in range(1, 11):
  print('* ' * stars)


# Now run your triangle back as well.
# *
# * *
# * * *
# * *
# *
# Hint: use two for loops

for stars in range(1, 11):
  print('* ' * stars)
for stars in range(9, 0, -1):
  print('* ' * stars)

# For an extra challenge to this assignment, you can also make the triangle like this (do this only after you finish the rest. Note: is very tricky):
# *
# * *
# * * *

size = 10
for i in range(size):
  print((i + 1) * '* ')





