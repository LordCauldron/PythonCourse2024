# We importeren hieronder een geheime lijst gevuld met getallen
from hidden import onze_lijst

# > Calculate the sum of the list called 'our_list'.
# This list is filled with random numbers
print(type(onze_lijst))
print(type(onze_lijst[0]))

# < CODE HERE >
ListSum = sum(onze_lijst)
ListAElements = len(onze_lijst)
ListAverage = ListSum / ListAElements
print(ListAverage)
# > Write a function to calculate the average of the elements in this list and print it

# < FUNCTION HERE >

def ListAverage(onze_lijst):
    ListAverageSum = sum(onze_lijst) / len(onze_lijst)
    return (ListAverageSum)

print(ListAverage(onze_lijst))
# > See if the element at index 5 is greater than the average

# < CODE HERE >
Index_5 = (onze_lijst[5])
AboveAveragequestion = Index_5 >= ListAverage(onze_lijst)
print(AboveAveragequestion)
# > You can also write a function for this: give this function a position in the list, and have it check whether the element at that position is greater than the average.

# < FUNCTION HERE >
def AboveAverage(List_nr):
  if onze_lijst[List_nr] >= ListAverage(onze_lijst):
    return(f'The indexed number in the list is {onze_lijst[List_nr]} and is thus above average')
  else:
    return(f'The indexed number is the list is {onze_lijst[List_nr]} and is thus not above average')

print(AboveAverage(5))
print(AboveAverage(2))
# > What is the last element in the list?
#-1
# < CODE HERE >
LastElement = onze_lijst[-1]
print(LastElement)
# > If you hadn't already done so: check this by looking at the last element in the list without using the length of the list.

# < CODE HERE >
LastElement = onze_lijst[-1]
print(LastElement)
# > What is the largest number in the list? Write a function that returns the index to this number

# < FUNCTION HERE > 
def LargestNumber(onze_lijst):
  MaxValue = max(onze_lijst)
  return(onze_lijst.index(max(onze_lijst)))
print(LargestNumber(onze_lijst))
print(onze_lijst[78]) #Control"
# > Put a 0 before and after this number, then check if this went well.
# So if 10 is the largest number the list becomes [..., 0, 10, 0, ...].

# < CODE HERE >
onze_lijst.insert(78, 0)
onze_lijst.insert(80, 0)
print(onze_lijst[78], onze_lijst[79], onze_lijst[80])
# > Find the largest number this time in the list by sorting the list and looking at the last element - you can use a function (sort) for this. Compare this with the largest number you get back from the max function

# < CODE HERE >
def LargestNRSort(onze_lijst):
  onze_lijst.sort(reverse=True)
  return(onze_lijst[0])
print(LargestNRSort(onze_lijst))
# Reverse the list so that now the smallest number is at the back. Check this by seeing if the first element is still the largest element.

# < CODE HERE >
def LargestNRSort(onze_lijst):
  onze_lijst.sort(reverse=True)
  return(onze_lijst[0])
print(LargestNRSort(onze_lijst))
# Empty the list.

# < CODE HERE >
onze_lijst.clear()
#> Create a string and fill it with at least 20 letters (does not have to be an existing word or the like)
# > Use input to ask for a letter and count how many times that letter is in the string

# < CODE HERE >
string = "im writing my assignments in english to make it simpler for my self, I hope that is not a problem."
letter = input("Please enter a letter: ")
letter_count = string.count(letter)
print(letter_count)

# Below is a list of passwords:
wachtwoorden = [
	'wachtwoord', '1234', '0000', 'mijn_verjaardag', 'naam_van_huisdier',
	'qwerty', 'admin', 'wachtw00rd'
]

# > Ask a user for his user number (which is the index (position) in the list)
user_number = int(input("Enter your user number (index): "))
if user_number < 0 or user_number >= len(wachtwoorden):
  print("Invalid user number.")
else:
  # > Ask a user for his password
  password = input("Enter your password: ")

  # > See if the password is correct
  if password == wachtwoorden[user_number]:
      print("Password is correct.")

    # > Have the user change the password
      new_password = input("Enter your new password: ")

    # > Save this change to the correct position in the list
      wachtwoorden[user_number] = new_password

      print(f"Password changed successfully. To {wachtwoorden[user_number]}")
  





# > Check that the password has been changed
