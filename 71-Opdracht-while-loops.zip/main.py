from hidden import shuffle, is_sorted, secret_number

#   __ _ _   _  ___  ___ ___
#  / _` | | | |/ _ \/ __/ __|
# | (_| | |_| |  __/\__ \__ \
#  \__, |\__,_|\___||___/___/
#  |___/

# hidden.py gives you a secret number called `secret_number`, this is different every time you run it. Write a program with a while loop which gives the user 3 tries to guess the number. If the user fails to guess the number correctly tell if it is greater or less than the secret number.
# hint use the if,elif,else construction we learned earlier
print("Guess")

print(secret_number)
attempts = 3
Guess = int(input(f'Guess the hidden number, its something between 0 and 10, what do you think it is?  you have {attempts} for it. '))
while Guess != secret_number:
  if attempts == 1 or attempts == 2:
    Guess = int(input((f" you have {attempts} left, so guess again? ")))
  
  if attempts != 0 and Guess < 1 or Guess > 10:
    attempts -= 1
    print(f"The number {Guess} is not not between 1 and 10, so try again ")
  elif attempts != 0 and Guess < secret_number:
    attempts -= 1
    print(f"The number {Guess} is not correct, but it is larger than the number. ")
  elif attempts != 0 and Guess > secret_number:
    attempts -= 1
    print(f"The number {Guess} is not correct, but it is smaller than the number. ")
  elif attempts == 0:
    print("you are out of attempts, to bad")
    break
if Guess == secret_number:
  print(f"Correct! you wrote {Guess} and guess what! the number was indeed {secret_number}")                    



#      _  _  __
#  ___(_)(_)/ _| ___ _ __ ___
# / __| || | |_ / _ \ '__/ __|
#| (__| || |  _|  __/ |  \__ \
# \___|_|/ |_|  \___|_|  |___/
#      |__/

# > Ask a user through a while loop for numbers from his students (comma numbers from 1 to 10).
# > If necessary, check that the number entered is between 1 and 10!
# > Save it in a list
# > If the user enters 0 he is done filling the list.

# Now that we have a list of numbers, we can use it to calculate things.
# > Using a for loop, calculate the number of elements in the list:
# > create a variable for the length

# > Using a for loop, calculate the average of the digits:
# > create a variable
# > use a for loop to add each digit to it
# > when that's done divide it by the number of numbers in the list

# > Using one for loop, calculate the following three things: how many satisfactions there are, the minimum and the maximum in the list:
# > Use three variables one for the number of satisfactions, one for the minimum and one for the maximum
# > In your for loop, use three if statements (at least one for the minimum and one for the maximum)

# > Now print the statistics about these grades you just calculated
# Initialize an empty list to store student numbers
print("Dijfers")

student_numbers = []

while True:
    number = int(input("Enter a number from your students (1 to 10), or 0 to finish: "))
    if number == 0:
        break  
    elif 1 <= number <= 10:
        student_numbers.append(number)
    else:
        print("Invalid input. Please enter a number between 1 and 10.")

num_elements = len(student_numbers)

average = sum(student_numbers) / num_elements if num_elements != 0 else 0

num_satisfactions = student_numbers.count(10)

minimum = min(student_numbers) if num_elements != 0 else None
maximum = max(student_numbers) if num_elements != 0 else None

# Print the statistics
print(f"Number of elements in the list: {num_elements}")
print(f"Average of the numbers in the list: {average}")
print(f"Number of satisfactions (numbers equal to 10): {num_satisfactions}")
print(f"Minimum in the list: {minimum}")
print(f"Maximum in the list: {maximum}")


#      _            __  __ _
#  ___| |__  _   _ / _|/ _| | ___
# / __| '_ \| | | | |_| |_| |/ _ \
# \__ \ | | | |_| |  _|  _| |  __/
# |___/_| |_|\__,_|_| |_| |_|\___|
#

# shuffle sort
# shuffle sort is one of the least efficient sort algorithms there is
# it proceeds as follows:
# > Take a list of numbers (for example, the list you made in the previous task)
# > Shuffle these randomly (like shuffling a deck of cards)
# > See if the list is sorted
# > If the list is sorted, you are done, if it is not sorted shuffle it again.
#
# We have already written the trickier parts for you:
# use the following function to see if a list is sorted
# `is_sorted(list)` > This returns True if the list is sorted and False if it is not.
# Use this function to shuffle a list
# `shuffle(list)` > this changes the existing list
#
# To see how the sorting goes you can print out your list in between



print("Shuffle")

shuffle(student_numbers)


print("Shuffled list:", student_numbers)


while not is_sorted(student_numbers):
    shuffle(student_numbers)


print("Sorted list:", student_numbers)